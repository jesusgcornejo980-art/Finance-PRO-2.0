import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, CalendarCheck } from 'lucide-react';
import { Button } from '../Button';

interface Props {
  onBack: () => void;
  onApply: (start: Date, end: Date) => void;
  initialStartDate: Date;
  initialEndDate: Date;
  selectionMode?: 'weekly' | 'monthly';
}

export const Screen12_2: React.FC<Props> = ({ onBack, onApply, initialStartDate, initialEndDate, selectionMode }) => {
  const [currentDate, setCurrentDate] = useState(new Date(initialStartDate));
  const [selectedStart, setSelectedStart] = useState<Date>(initialStartDate);
  const [selectedEnd, setSelectedEnd] = useState<Date>(initialEndDate);
  
  // Logic to determine which preset is active based on dates passed via props
  const getActivePreset = (start: Date, end: Date): 'today' | 'week' | 'month' | null => {
      const s = new Date(start); s.setHours(0,0,0,0);
      const e = new Date(end); e.setHours(0,0,0,0);
      const now = new Date(); now.setHours(0,0,0,0);

      // Check Today
      if (s.getTime() === now.getTime() && e.getTime() === now.getTime()) return 'today';

      // Check Week (Monday to Sunday)
      const currentDay = now.getDay() || 7; // 1=Mon, 7=Sun
      const weekStart = new Date(now); 
      weekStart.setDate(now.getDate() - currentDay + 1); weekStart.setHours(0,0,0,0);
      const weekEnd = new Date(weekStart); 
      weekEnd.setDate(weekStart.getDate() + 6); weekEnd.setHours(0,0,0,0);
      
      if (s.getTime() === weekStart.getTime() && e.getTime() === weekEnd.getTime()) return 'week';

      // Check Month
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0); monthEnd.setHours(0,0,0,0);
      
      if (s.getTime() === monthStart.getTime() && e.getTime() === monthEnd.getTime()) return 'month';

      return null;
  };

  const [activePreset, setActivePreset] = useState<'today' | 'week' | 'month' | null>(() => 
    getActivePreset(initialStartDate, initialEndDate)
  );

  // Calendar Logic
  const daysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = (date: Date) => {
    const day = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    return day === 0 ? 6 : day - 1; // Adjust so Monday is 0, Sunday is 6
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleDateClick = (day: number) => {
    const clickedDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    clickedDate.setHours(0, 0, 0, 0);

    // Special behavior if we are in Monthly selection mode
    if (selectionMode === 'monthly') {
        const start = new Date(clickedDate.getFullYear(), clickedDate.getMonth(), 1);
        const end = new Date(clickedDate.getFullYear(), clickedDate.getMonth() + 1, 0);
        start.setHours(0,0,0,0);
        end.setHours(0,0,0,0);
        
        setSelectedStart(start);
        setSelectedEnd(end);
        setActivePreset('month');
        return;
    }

    // Default Behavior (Range selection)
    setActivePreset(null); // Clear preset when manually interacting with calendar

    // If we have a range already selected (Start != End), clicking means we are starting a NEW range selection.
    if (selectedStart.getTime() !== selectedEnd.getTime()) {
        setSelectedStart(clickedDate);
        setSelectedEnd(clickedDate);
    } else {
        // If we have a single day selected (Start == End), clicking means we are selecting the END date.
        if (clickedDate < selectedStart) {
            // User clicked a date before the start, swap them
            setSelectedEnd(selectedStart);
            setSelectedStart(clickedDate);
        } else {
            // User clicked a date after start, extend range
            setSelectedEnd(clickedDate);
        }
    }
  };

  const isSelected = (day: number) => {
    const d = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    d.setHours(0,0,0,0);
    const s = new Date(selectedStart); s.setHours(0,0,0,0);
    const e = new Date(selectedEnd); e.setHours(0,0,0,0);

    return d.getTime() === s.getTime() || d.getTime() === e.getTime();
  };

  const isInRange = (day: number) => {
    const d = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    d.setHours(0,0,0,0);
    const s = new Date(selectedStart); s.setHours(0,0,0,0);
    const e = new Date(selectedEnd); e.setHours(0,0,0,0);

    return d > s && d < e;
  };

  const selectPreset = (type: 'week' | 'month' | 'today') => {
      setActivePreset(type);
      const now = new Date();
      now.setHours(0,0,0,0);
      
      if (type === 'today') {
          setSelectedStart(now);
          setSelectedEnd(now);
          setCurrentDate(now);
      } else if (type === 'week') {
          const currentDay = now.getDay() || 7; 
          const start = new Date(now); 
          start.setDate(now.getDate() - currentDay + 1);
          const end = new Date(start); 
          end.setDate(start.getDate() + 6);
          
          setSelectedStart(start);
          setSelectedEnd(end);
          setCurrentDate(start);
      } else if (type === 'month') {
          const start = new Date(now.getFullYear(), now.getMonth(), 1);
          const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
          setSelectedStart(start);
          setSelectedEnd(end);
          setCurrentDate(start);
      }
  };

  // Rendering Days
  const renderDays = () => {
    const totalDays = daysInMonth(currentDate);
    const startDay = firstDayOfMonth(currentDate);
    const days = [];

    // Empty cells for previous month
    for (let i = 0; i < startDay; i++) {
        days.push(<div key={`empty-${i}`} className="h-10 w-10"></div>);
    }

    // Days of current month
    for (let i = 1; i <= totalDays; i++) {
        const selected = isSelected(i);
        const inRange = isInRange(i);
        
        // Connect range visuals
        let wrapperClass = "h-10 w-full flex items-center justify-center relative my-1";
        if (inRange) wrapperClass += " bg-fuchsia-900/30";
        if (selected) {
             const d = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
             const s = new Date(selectedStart); s.setHours(0,0,0,0);
             const e = new Date(selectedEnd); e.setHours(0,0,0,0);
             d.setHours(0,0,0,0);
             
             if (s.getTime() !== e.getTime()) {
                 if (d.getTime() === s.getTime()) wrapperClass += " bg-gradient-to-r from-transparent to-fuchsia-900/30 rounded-l-full";
                 if (d.getTime() === e.getTime()) wrapperClass += " bg-gradient-to-l from-transparent to-fuchsia-900/30 rounded-r-full";
             }
        }

        days.push(
            <div key={i} className={wrapperClass} onClick={() => handleDateClick(i)}>
                <button 
                    className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                        selected 
                        ? 'bg-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/40 z-10' 
                        : inRange 
                            ? 'text-fuchsia-200' 
                            : 'text-white hover:bg-white/10'
                    }`}
                >
                    {i}
                </button>
            </div>
        );
    }
    return days;
  };

  const formatMonthYear = (date: Date) => {
      return date.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });
  };

  return (
    <div className="flex flex-col h-full bg-black relative">
        
        {/* --- HEADER --- */}
        <div className="px-4 py-4 pt-10 flex items-center justify-between z-10 sticky top-0 bg-black/90 backdrop-blur-md border-b border-white/5">
            <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-gray-300 hover:text-white">
                <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="text-sm font-bold text-white uppercase tracking-wider">Filtrar por Fecha</span>
            <div className="w-10"></div>
        </div>

        {/* --- CONTENT --- */}
        <div className="flex-1 overflow-y-auto no-scrollbar px-6 pt-6">
            
            {/* Quick Filters */}
            <div className="flex gap-2 mb-8 overflow-x-auto no-scrollbar pb-2">
                <button 
                    onClick={() => selectPreset('today')} 
                    className={`px-4 py-2 rounded-xl border text-xs font-bold whitespace-nowrap transition-colors ${
                        activePreset === 'today' 
                        ? 'border-fuchsia-500/50 bg-fuchsia-500/10 text-fuchsia-400' 
                        : 'border-white/10 bg-surface text-gray-300 hover:bg-white/5'
                    }`}
                >
                    Hoy
                </button>
                <button 
                    onClick={() => selectPreset('week')} 
                    className={`px-4 py-2 rounded-xl border text-xs font-bold whitespace-nowrap transition-colors ${
                        activePreset === 'week' 
                        ? 'border-fuchsia-500/50 bg-fuchsia-500/10 text-fuchsia-400' 
                        : 'border-white/10 bg-surface text-gray-300 hover:bg-white/5'
                    }`}
                >
                    Esta Semana
                </button>
                <button 
                    onClick={() => selectPreset('month')} 
                    className={`px-4 py-2 rounded-xl border text-xs font-bold whitespace-nowrap transition-colors ${
                        activePreset === 'month' 
                        ? 'border-fuchsia-500/50 bg-fuchsia-500/10 text-fuchsia-400' 
                        : 'border-white/10 bg-surface text-gray-300 hover:bg-white/5'
                    }`}
                >
                    Este Mes
                </button>
            </div>

            {/* Calendar Container */}
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-4 shadow-xl">
                
                {/* Month Navigation */}
                <div className="flex items-center justify-between mb-6 px-2">
                    <button onClick={prevMonth} className="p-2 hover:bg-white/5 rounded-full text-gray-400 hover:text-white">
                        <ChevronLeft className="w-5 h-5" />
                    </button>
                    <span className="text-lg font-bold text-white capitalize">{formatMonthYear(currentDate)}</span>
                    <button onClick={nextMonth} className="p-2 hover:bg-white/5 rounded-full text-gray-400 hover:text-white">
                        <ChevronRight className="w-5 h-5" />
                    </button>
                </div>

                {/* Days Header */}
                <div className="grid grid-cols-7 mb-2">
                    {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d, i) => (
                        <div key={i} className="text-center text-xs font-bold text-gray-600 py-2">
                            {d}
                        </div>
                    ))}
                </div>

                {/* Days Grid */}
                <div className="grid grid-cols-7">
                    {renderDays()}
                </div>

            </div>

            {/* Selected Range Display */}
            <div className="mt-8 flex justify-between items-center bg-surface/50 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-400">
                        <CalendarCheck className="w-5 h-5" />
                    </div>
                    <div>
                        <p className="text-[10px] text-gray-500 uppercase font-bold">Desde</p>
                        <p className="text-sm font-bold text-white">{selectedStart.toLocaleDateString('es-ES', {day: 'numeric', month: 'short'})}</p>
                    </div>
                </div>
                <div className="h-8 w-[1px] bg-white/10"></div>
                <div>
                    <p className="text-[10px] text-gray-500 uppercase font-bold text-right">Hasta</p>
                    <p className="text-sm font-bold text-white text-right">{selectedEnd.toLocaleDateString('es-ES', {day: 'numeric', month: 'short'})}</p>
                </div>
            </div>

        </div>

        {/* --- FOOTER --- */}
        <div className="p-6 pt-4 bg-black border-t border-white/5">
            <Button onClick={() => onApply(selectedStart, selectedEnd)}>
                APLICAR FILTRO
            </Button>
        </div>

    </div>
  );
};