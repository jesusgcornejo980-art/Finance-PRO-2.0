import React from 'react';
import { Check, ArrowRight } from 'lucide-react';
import { Button } from '../Button';

interface Props {
  onFinish: () => void;
  categoriesCount: number;
  debtsCount: number;
  paymentMethodsCount: number;
}

export const Screen9: React.FC<Props> = ({ onFinish, categoriesCount, debtsCount, paymentMethodsCount }) => {
  return (
    <div className="flex flex-col h-full bg-black relative overflow-hidden">
      
      {/* Background Ambience */}
      <div className="absolute top-[-20%] left-[-20%] w-[140%] h-[60%] bg-purple-900/20 blur-[100px] rounded-full pointer-events-none" />
      {/* Wave effect simulation at bottom */}
      <div className="absolute bottom-0 left-0 w-full h-[40%] bg-gradient-to-t from-purple-900/20 via-transparent to-transparent opacity-50 pointer-events-none" />
      <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-fuchsia-900/20 blur-[80px] rounded-full pointer-events-none" />

      {/* Content Container */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 z-10 relative">
        
        {/* Success Icon */}
        <div className="relative mb-10 animate-fade-in-up">
            {/* Glow */}
            <div className="absolute inset-0 bg-fuchsia-600/30 blur-2xl rounded-full scale-110"></div>
            {/* Circle */}
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-700 flex items-center justify-center shadow-2xl shadow-purple-900/50 relative z-10 border border-white/10">
                <Check className="w-14 h-14 text-white stroke-[3]" />
            </div>
        </div>

        <h1 className="text-4xl font-bold mb-3 text-center tracking-tight animate-fade-in-up" style={{animationDelay: '100ms'}}>
          ¡Todo listo!
        </h1>

        <p className="text-lg text-center text-gray-300 mb-12 max-w-[280px] leading-relaxed animate-fade-in-up" style={{animationDelay: '200ms'}}>
          ¡Todo listo para dominar tus finanzas!
        </p>

        {/* Summary Cards */}
        <div className="w-full space-y-4 px-2">
            {[
                { label: `${paymentMethodsCount} Métodos de pago` },
                { label: `${debtsCount} Deudas registradas` },
                { label: `${categoriesCount} Categorías activas` }
            ].map((item, idx) => (
                <div 
                    key={idx} 
                    className="bg-surface/40 backdrop-blur-md border border-white/5 rounded-2xl p-5 flex items-center gap-4 shadow-lg animate-fade-in-up hover:bg-surface/60 transition-colors" 
                    style={{ animationDelay: `${300 + (idx * 100)}ms` }}
                >
                    <div className="w-2.5 h-2.5 rounded-full bg-fuchsia-500 shadow-[0_0_8px_rgba(217,70,239,0.8)]"></div>
                    <span className="text-white font-medium text-sm">{item.label}</span>
                </div>
            ))}
        </div>
      </div>

      {/* Footer */}
      <div className="p-6 pb-8 z-10 animate-fade-in-up" style={{animationDelay: '600ms'}}>
        <Button onClick={onFinish}>
            <div className="flex items-center justify-center gap-2">
                Inicia tu libertad financiera <ArrowRight className="w-5 h-5" />
            </div>
        </Button>
      </div>
    </div>
  );
};