import React, { useState } from 'react';
import { ChevronLeft, Plus, CreditCard, Wallet, Banknote, X, Landmark, CircleDollarSign } from 'lucide-react';
import { Button } from '../Button';
import { PaymentMethod } from '../../types';

interface Props {
  onBack: () => void;
  onFinish: () => void;
  methods: PaymentMethod[];
  setMethods: React.Dispatch<React.SetStateAction<PaymentMethod[]>>;
  isEditMode?: boolean;
}

export const Screen8: React.FC<Props> = ({ onBack, onFinish, methods, setMethods, isEditMode = false }) => {
  const [showIntroModal, setShowIntroModal] = useState(!isEditMode);
  const [editingItem, setEditingItem] = useState<PaymentMethod | null>(null);

  const formatCurrency = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return '$0.00';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(num);
  };

  const getIcon = (type: string) => {
    switch(type) {
      case 'cash': return Banknote;
      case 'debit': return Wallet;
      case 'credit': return CreditCard;
      default: return CircleDollarSign;
    }
  };

  const handleAddNew = () => {
    setEditingItem({
      id: Date.now(),
      name: '',
      subtitle: '',
      balance: '',
      type: 'debit',
      label: 'BALANCE'
    });
  };

  const handleSave = () => {
    if (!editingItem) return;
    setMethods(prev => {
      const exists = prev.find(m => m.id === editingItem.id);
      if (exists) {
        return prev.map(m => m.id === editingItem.id ? editingItem : m);
      } else {
        return [...prev, editingItem];
      }
    });
    setEditingItem(null);
  };

  const handleDelete = () => {
    if (!editingItem) return;
    setMethods(prev => prev.filter(m => m.id !== editingItem.id));
    setEditingItem(null);
  }

  return (
    <div className="flex flex-col h-full bg-black relative">
      
      {/* HEADER */}
      <div className="px-4 py-4 flex items-center justify-between bg-black/80 backdrop-blur-md sticky top-0 z-30 border-b border-white/5">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-gray-300 hover:text-white">
            <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-lg">Métodos de Pago</h2>
        <div className="w-10"></div> {/* Spacer to keep title centered */}
      </div>

      {/* LIST */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-32 no-scrollbar">
        {methods.map((item) => {
          const Icon = getIcon(item.type);
          return (
            <div 
              key={item.id}
              onClick={() => setEditingItem(item)}
              className="bg-surface border border-white/5 rounded-3xl p-5 flex items-center justify-between animate-fade-in-up active:scale-[0.98] transition-transform cursor-pointer hover:border-white/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-800/50 border border-white/5 flex items-center justify-center">
                  <Icon className="w-6 h-6 text-fuchsia-400" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">{item.name}</h3>
                  <p className="text-xs text-gray-500">{item.subtitle}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">{item.label}</p>
                <p className="font-bold text-lg text-white">{formatCurrency(item.balance)}</p>
              </div>
            </div>
          );
        })}

        {methods.length === 0 && (
            <div className="text-center py-10 text-gray-500">
                <p>No hay métodos de pago configurados.</p>
                <p className="text-xs mt-2">Agrega efectivo o tarjetas para continuar.</p>
            </div>
        )}

        <div className="flex justify-center mt-4">
            <button 
                onClick={handleAddNew}
                className="px-8 py-3 rounded-full bg-purple-600 text-white font-bold text-sm shadow-lg shadow-purple-600/20 hover:bg-purple-500 transition-all flex items-center gap-2 transform hover:scale-105 active:scale-95"
            >
                <Plus className="w-4 h-4" />
                AGREGAR
            </button>
        </div>
      </div>

      {/* FOOTER */}
      <div className="p-4 pt-2 pb-6 bg-gradient-to-t from-black via-black to-transparent sticky bottom-0 z-30">
        <Button onClick={onFinish} showIcon={!isEditMode}>
            {isEditMode ? 'GUARDAR CAMBIOS' : 'CONTINUAR'}
        </Button>
      </div>

      {/* EDIT MODAL */}
      {editingItem && (
        <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
             <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl relative overflow-hidden animate-slide-up">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold">
                        {methods.find(m => m.id === editingItem.id) ? 'Editar Método' : 'Nuevo Método'}
                    </h3>
                    <button onClick={() => setEditingItem(null)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <div className="space-y-4">
                     {/* Type Selector */}
                     <div className="grid grid-cols-3 gap-2 mb-4">
                        {['cash', 'debit', 'credit'].map((t) => (
                            <button
                                key={t}
                                onClick={() => setEditingItem({...editingItem, type: t as any, label: t === 'credit' ? 'DISPONIBLE' : 'BALANCE'})}
                                className={`py-2 rounded-xl text-xs font-bold uppercase border transition-colors ${
                                    editingItem.type === t 
                                    ? 'bg-purple-600 border-purple-600 text-white' 
                                    : 'bg-transparent border-white/10 text-gray-400 hover:bg-white/5'
                                }`}
                            >
                                {t === 'cash' ? 'Efectivo' : t === 'debit' ? 'Débito' : 'Crédito'}
                            </button>
                        ))}
                     </div>

                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Nombre</label>
                        <input 
                            type="text" 
                            value={editingItem.name}
                            onChange={(e) => setEditingItem({...editingItem, name: e.target.value})}
                            className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500"
                            placeholder="Ej. Billetera"
                        />
                    </div>
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Detalle</label>
                        <input 
                            type="text" 
                            value={editingItem.subtitle}
                            onChange={(e) => setEditingItem({...editingItem, subtitle: e.target.value})}
                            className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500"
                            placeholder="Ej. Ahorros"
                        />
                    </div>
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">
                            {editingItem.label === 'DISPONIBLE' ? 'Crédito Disponible' : 'Balance Actual'}
                        </label>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                            <input 
                                type="number" 
                                value={editingItem.balance}
                                onChange={(e) => setEditingItem({...editingItem, balance: e.target.value})}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 pl-8 text-white focus:outline-none focus:border-purple-500"
                            />
                        </div>
                    </div>

                    <div className="pt-4 flex flex-col gap-3">
                        <Button onClick={handleSave}>Guardar</Button>
                         {methods.find(m => m.id === editingItem.id) && (
                             <button 
                                onClick={handleDelete}
                                className="w-full py-3 text-red-400 font-bold text-sm hover:bg-red-500/10 rounded-xl transition-colors">
                                Eliminar
                            </button>
                        )}
                    </div>
                </div>
             </div>
        </div>
      )}

      {/* INTRO MODAL */}
      {showIntroModal && (
        <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
            <div className="bg-surface border border-white/10 rounded-[2rem] p-8 w-full max-w-sm shadow-2xl relative overflow-hidden flex flex-col items-center">
                {/* Modal Glow */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-purple-500"></div>
                <div className="absolute -top-20 -right-20 w-60 h-60 bg-purple-600/10 blur-[60px] rounded-full pointer-events-none"></div>

                <div className="flex justify-center mb-6 mt-2 relative">
                    <div className="absolute inset-0 bg-fuchsia-500/20 blur-xl rounded-full"></div>
                    <div className="w-20 h-20 rounded-full bg-slate-900 border border-white/10 flex items-center justify-center shadow-lg relative z-10">
                        <Wallet className="w-10 h-10 text-fuchsia-400" />
                    </div>
                </div>

                <h3 className="text-2xl font-bold text-center mb-4">Configuración Final</h3>
                
                <p className="text-center text-gray-300 text-sm mb-8 leading-relaxed">
                    Este es el paso final. Aquí debes revisar y confirmar tus métodos de pago iniciales (Efectivo y Tarjetas). Esto es fundamental para que la app pueda calcular tus saldos reales y dividir tus ingresos automáticamente.
                </p>

                <Button onClick={() => setShowIntroModal(false)}>
                    ENTENDIDO
                </Button>
            </div>
        </div>
      )}
    </div>
  );
};