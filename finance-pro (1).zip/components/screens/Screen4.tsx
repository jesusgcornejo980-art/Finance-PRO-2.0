import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { Button } from '../Button';
import { ChevronRight, ChevronLeft } from 'lucide-react';

interface Props {
  onNext: () => void;
  onBack?: () => void;
}

export const Screen4: React.FC<Props> = ({ onNext, onBack }) => {
  const data = [
    { name: 'Disponible', value: 100 },
  ];

  // Visual only data for the colored ring segments background
  const segments = [
    { name: 'Necesidades', value: 50, color: '#9333ea' }, // purple-600
    { name: 'Gustos', value: 20, color: '#a855f7' }, // purple-500
    { name: 'Ahorros', value: 30, color: '#d946ef' }, // fuchsia-500
  ];

  return (
    <div className="flex flex-col h-full bg-black relative">
       {/* Top Status Bar Placeholder (Safe Area) & Back Button */}
       <div className="h-16 w-full flex items-center px-4 relative z-20">
          {onBack && (
            <button onClick={onBack} className="w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center text-white hover:bg-slate-700 transition-colors">
                <ChevronLeft className="w-6 h-6" />
            </button>
          )}
       </div>

       <div className="px-6 text-center mb-2 shrink-0">
         <h2 className="text-2xl font-bold">
            La <span className="text-fuchsia-500">Regla 50-30-20</span>
         </h2>
         <p className="text-sm text-gray-400 mt-1">
            Automatiza tu presupuesto dividiendo tus ingresos para un crecimiento constante.
         </p>
       </div>

       {/* Chart Area - Reduced height to pull cards up */}
       <div className="flex-1 min-h-[220px] max-h-[300px] relative flex items-center justify-center shrink-0">
            <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    {/* The colored segments */}
                    <Pie
                        data={segments}
                        cx="50%"
                        cy="50%"
                        innerRadius={80}
                        outerRadius={100}
                        paddingAngle={0}
                        dataKey="value"
                        stroke="none"
                        cornerRadius={10}
                        startAngle={90}
                        endAngle={-270}
                        animationDuration={800}
                        animationBegin={0}
                    >
                        {segments.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                    </Pie>
                    {/* Inner track bg */}
                    <Pie
                        data={[{ value: 100 }]}
                        cx="50%"
                        cy="50%"
                        innerRadius={70}
                        outerRadius={80}
                        dataKey="value"
                        stroke="none"
                        fill="#1e1b4b" // dark purple bg
                        animationDuration={800}
                        animationBegin={0}
                    />
                </PieChart>
            </ResponsiveContainer>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-4xl font-bold text-white">100%</span>
                <span className="text-[10px] tracking-widest text-fuchsia-400 uppercase font-bold mt-1">Disponible</span>
            </div>
       </div>

       {/* Legend / Info Cards - Moved up */}
       <div className="px-6 pb-6 space-y-3 relative z-10 flex-1 flex flex-col justify-center">
            <div className="bg-surface rounded-2xl p-4 flex items-center justify-between border border-white/5 shadow-lg">
                <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-purple-600 shadow-[0_0_8px_#9333ea]"></div>
                    <div>
                        <div className="font-bold text-sm">Necesidades</div>
                        <div className="text-xs text-gray-500">Renta, servicios, despensa</div>
                    </div>
                </div>
                <div className="text-lg font-bold text-purple-400">50%</div>
            </div>

            <div className="bg-surface rounded-2xl p-4 flex items-center justify-between border border-white/5 shadow-lg">
                <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-fuchsia-500 shadow-[0_0_8px_#d946ef]"></div>
                    <div>
                        <div className="font-bold text-sm">Ahorros</div>
                        <div className="text-xs text-gray-500">Fondo de emergencia, inversiones</div>
                    </div>
                </div>
                <div className="text-lg font-bold text-fuchsia-400">30%</div>
            </div>

            <div className="bg-surface rounded-2xl p-4 flex items-center justify-between border border-white/5 shadow-lg">
                <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-purple-500 shadow-[0_0_8px_#a855f7]"></div>
                    <div>
                        <div className="font-bold text-sm">Gustos</div>
                        <div className="text-xs text-gray-500">Restaurantes, diversión</div>
                    </div>
                </div>
                <div className="text-lg font-bold text-purple-400">20%</div>
            </div>
       </div>

       {/* Footer Button */}
       <div className="p-6 pt-2 pb-8 sticky bottom-0 bg-gradient-to-t from-black via-black to-transparent shrink-0">
         <Button onClick={onNext}>
            <div className="flex items-center justify-center gap-2">
                Siguiente <ChevronRight className="w-5 h-5" />
            </div>
         </Button>
       </div>
    </div>
  );
};