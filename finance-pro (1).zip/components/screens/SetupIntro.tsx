import React from 'react';
import { Settings, Sparkles, ChevronLeft } from 'lucide-react';
import { Button } from '../Button';

interface Props {
  onNext: () => void;
  onBack: () => void;
}

export const SetupIntro: React.FC<Props> = ({ onNext, onBack }) => {
  return (
    <div className="flex flex-col h-full bg-slate-950 relative">
        <button onClick={onBack} className="absolute top-6 left-6 z-30 w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center text-white hover:bg-slate-700 transition-colors">
            <ChevronLeft className="w-6 h-6" />
        </button>

      <div className="flex-1 flex flex-col items-center justify-center relative">
        {/* Animated Gear Icon */}
        <div className="w-48 h-48 rounded-full bg-purple-900/10 border border-purple-500/20 flex items-center justify-center relative mb-12">
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-violet-500/20 to-transparent animate-spin-slow"></div>
            <Settings className="w-20 h-20 text-fuchsia-400 drop-shadow-[0_0_15px_rgba(232,121,249,0.5)]" />
            <Sparkles className="absolute top-10 right-10 w-8 h-8 text-violet-300 animate-pulse" />
        </div>

        <h1 className="text-3xl font-bold mb-4 text-center px-6">
          Personaliza tu <br/>
          Experiencia
        </h1>

        <p className="text-gray-400 text-center px-8 leading-relaxed mb-8">
          Para ofrecerte un control semanal exacto, necesitamos conocer un poco más sobre tus finanzas.
        </p>
      </div>

      <div className="p-6 pb-12">
        <Button onClick={onNext}>
          COMENZAR
        </Button>
        
        {/* Progress Dots */}
        <div className="flex justify-center items-center gap-2 mt-8">
            <div className="w-1.5 h-1.5 rounded-full bg-gray-700" />
            <div className="w-1.5 h-1.5 rounded-full bg-gray-700" />
            <div className="w-8 h-1.5 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500" />
        </div>
        
        <p className="text-[10px] text-center text-gray-600 mt-4 uppercase tracking-widest">
            Paso 1: Configuración Inicial
        </p>
      </div>
    </div>
  );
};
