import React, { useState, useMemo } from 'react';
import { ChevronLeft, Calendar, ArrowUpRight, ArrowDownRight, TrendingUp, DollarSign, PieChart as PieChartIcon, Activity, CalendarSearch } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';
import { DateRange, Currency } from '../../types';

interface Props {
  spentAmounts: { needs: number; savings: number; wants: number };
  transactionCount: number;
  dateRange: DateRange;
  onBack: () => void;
  onOpenFilter: (currentMode: 'weekly' | 'monthly') => void;
  currency: Currency;
}

export const Screen12_1: React.FC<Props> = ({ spentAmounts, transactionCount, dateRange, onBack, onOpenFilter, currency }) => {
  const [period, setPeriod] = useState<'weekly' | 'monthly'>('weekly');

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 0
    }).format(value);
  };

  const formatDateRange = (start: Date, end: Date) => {
    const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short' };
    const startStr = start.toLocaleDateString('es-ES', options);
    const endStr = end.toLocaleDateString('es-ES', options);
    return `${startStr} - ${endStr}`;
  };

  // --- Dynamic Calculations based on Period ---
  
  // Simulation Multiplier: If monthly, we project x4 roughly
  const multiplier = period === 'monthly' ? 4 : 1;

  const displayNeeds = spentAmounts.needs * multiplier;
  const displayWants = spentAmounts.wants * multiplier;
  const displaySavings = spentAmounts.savings * multiplier;
  
  const totalSpent = displayNeeds + displayWants + displaySavings;
  
  // Average Daily Spend 
  // Weekly: Divide by 7
  // Monthly: Divide by 30
  const divider = period === 'monthly' ? 30 : 7;
  const averageDailySpend = Math.round(totalSpent / divider);

  const displayTransactionCount = transactionCount * multiplier;

  // Top Category Determination
  let topCategoryName = '-';
  let maxAmount = 0;
  
  if (displayNeeds > maxAmount) {
      maxAmount = displayNeeds;
      topCategoryName = 'Necesidades';
  }
  if (displayWants > maxAmount) {
      maxAmount = displayWants;
      topCategoryName = 'Gustos';
  }
  if (displaySavings > maxAmount) {
      maxAmount = displaySavings;
      topCategoryName = 'Ahorro';
  }
  if (totalSpent === 0) topCategoryName = '-';

  // Fixed Percent Calculation (Needs / Total)
  const fixedPercent = totalSpent > 0 ? Math.round((displayNeeds / totalSpent) * 100) : 0;
  const fixedStatus = fixedPercent <= 50 ? 'OK' : 'ALTO';
  const fixedStatusColor = fixedPercent <= 50 ? 'text-emerald-400' : 'text-red-400';

  // --- Mock Data for Charts (Zeroed out or Simulated) ---
  
  // Bar Chart Data (Weekly = Days, Monthly = Weeks)
  const activityData = useMemo(() => {
      if (period === 'weekly') {
          return [
            { label: 'Lun', income: 0, expense: spentAmounts.needs * 0.1 },
            { label: 'Mar', income: 0, expense: spentAmounts.wants * 0.2 },
            { label: 'Mié', income: 0, expense: spentAmounts.needs * 0.2 },
            { label: 'Jue', income: 0, expense: spentAmounts.savings * 0.5 },
            { label: 'Vie', income: 0, expense: spentAmounts.wants * 0.8 },
            { label: 'Sáb', income: 0, expense: spentAmounts.wants * 0.5 },
            { label: 'Dom', income: 0, expense: 0 },
          ];
      } else {
          // Monthly View (4 Weeks)
          return [
            { label: 'Sem 1', income: 0, expense: totalSpent * 0.20 },
            { label: 'Sem 2', income: 0, expense: totalSpent * 0.25 },
            { label: 'Sem 3', income: 0, expense: totalSpent * 0.35 },
            { label: 'Sem 4', income: 0, expense: totalSpent * 0.20 },
          ];
      }
  }, [period, spentAmounts, totalSpent]);

  // Area Chart Data
  const savingsTrendData = useMemo(() => {
     const dataPoints = period === 'weekly' ? 7 : 15; // less points for clean chart
     return Array.from({ length: dataPoints }).map((_, i) => ({
         name: i.toString(),
         amount: (displaySavings / dataPoints) * (i + 1) // Linear growth simulation
     }));
  }, [period, displaySavings]);

  // Colors for Recharts
  const barColors = { income: '#10b981', expense: '#9333ea' }; // Emerald & Purple

  return (
    <div className="flex flex-col h-full bg-black relative">
        
        {/* --- HEADER --- */}
        <div className="px-4 py-4 pt-10 flex items-center justify-between z-10 sticky top-0 bg-black/80 backdrop-blur-md border-b border-white/5">
            <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-gray-300 hover:text-white">
                <ChevronLeft className="w-5 h-5" />
            </button>
            
            <div className="flex flex-col items-center">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Análisis Detallado</span>
                <div className="flex items-center gap-2 mt-1">
                    <Calendar className="w-3 h-3 text-fuchsia-500" />
                    <span className="text-sm font-bold text-white capitalize">
                        {period === 'weekly' ? formatDateRange(dateRange.startDate, dateRange.endDate) : 'Este Mes'}
                    </span>
                </div>
            </div>

            <button 
                onClick={() => onOpenFilter(period)}
                className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
            >
                <CalendarSearch className="w-5 h-5" />
            </button>
        </div>

        {/* --- CONTENT --- */}
        <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-10 pt-6 space-y-8">
            
            {/* 1. PERIOD SELECTOR */}
            <div className="bg-[#12121a] p-1 rounded-xl flex border border-white/10">
                <button 
                    onClick={() => setPeriod('weekly')}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${period === 'weekly' ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}
                >
                    SEMANAL
                </button>
                <button 
                     onClick={() => setPeriod('monthly')}
                     className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${period === 'monthly' ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}
                >
                    MENSUAL
                </button>
            </div>

            {/* 2. INCOME vs EXPENSE CHART */}
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-5 relative overflow-hidden">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-white text-sm">Flujo de Caja ({period === 'weekly' ? 'Días' : 'Semanas'})</h3>
                    <div className="flex gap-3">
                         <div className="flex items-center gap-1">
                            <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                            <span className="text-[10px] text-gray-400">Ingreso</span>
                         </div>
                         <div className="flex items-center gap-1">
                            <div className="w-2 h-2 rounded-full bg-purple-600"></div>
                            <span className="text-[10px] text-gray-400">Gasto</span>
                         </div>
                    </div>
                </div>

                <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={activityData} barSize={period === 'weekly' ? 8 : 16}>
                            <XAxis 
                                dataKey="label" 
                                axisLine={false} 
                                tickLine={false} 
                                tick={{fill: '#6b7280', fontSize: 10}} 
                                dy={10}
                            />
                            <Tooltip 
                                contentStyle={{backgroundColor: '#1f2937', borderColor: '#374151', borderRadius: '8px', fontSize: '12px'}}
                                cursor={{fill: 'rgba(255,255,255,0.05)'}}
                                labelStyle={{color: '#9ca3af'}}
                                formatter={(value: number) => [formatCurrency(value), '']}
                            />
                            <Bar name="Ingreso" dataKey="income" fill={barColors.income} radius={[4, 4, 0, 0]} />
                            <Bar name="Gasto" dataKey="expense" fill={barColors.expense} radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* 3. SAVINGS EVOLUTION */}
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-5 relative">
                <div className="mb-4">
                     <h3 className="font-bold text-white text-sm">Proyección de Ahorro</h3>
                     <p className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1">
                        <TrendingUp className="w-3 h-3" />
                        Acumulado del periodo
                     </p>
                </div>
                
                <div className="h-40 w-full -ml-4">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={savingsTrendData}>
                            <defs>
                                <linearGradient id="colorSavings" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <Tooltip 
                                contentStyle={{backgroundColor: '#1f2937', borderColor: '#374151', borderRadius: '8px', fontSize: '12px'}} 
                                formatter={(value: number) => [formatCurrency(value), 'Ahorro']}
                            />
                            <Area type="monotone" dataKey="amount" stroke="#2dd4bf" strokeWidth={3} fillOpacity={1} fill="url(#colorSavings)" />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* 4. KEY METRICS GRID */}
            <div>
                 <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Parámetros de Gasto ({period === 'weekly' ? 'Sem' : 'Mes'})</h3>
                 <div className="grid grid-cols-2 gap-3">
                    <div className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex flex-col gap-2">
                        <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400">
                            <DollarSign className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] text-gray-500 font-bold uppercase">Gasto Promedio Diario</span>
                        <span className="text-lg font-bold text-white">{formatCurrency(averageDailySpend)}</span>
                    </div>

                    <div className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex flex-col gap-2">
                        <div className="w-8 h-8 rounded-lg bg-pink-500/10 flex items-center justify-center text-pink-400">
                            <ArrowUpRight className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] text-gray-500 font-bold uppercase">Categoría Top</span>
                        <span className="text-lg font-bold text-white truncate w-full">{topCategoryName}</span>
                    </div>

                     <div className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex flex-col gap-2">
                        <div className="w-8 h-8 rounded-lg bg-yellow-500/10 flex items-center justify-center text-yellow-400">
                            <PieChartIcon className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] text-gray-500 font-bold uppercase">% Fijo (50%)</span>
                        <span className="text-lg font-bold text-white">{fixedPercent}% <span className={`text-[10px] ${fixedStatusColor}`}>{fixedStatus}</span></span>
                    </div>

                    <div className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex flex-col gap-2">
                        <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400">
                            <Activity className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] text-gray-500 font-bold uppercase">Transacciones</span>
                        <span className="text-lg font-bold text-white">{displayTransactionCount}</span>
                    </div>
                 </div>
            </div>

            {/* 5. CATEGORY BREAKDOWN LIST */}
            <div>
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Desglose por Categoría</h3>
                
                <div className="space-y-3">
                    {[
                        { label: 'Necesidades', amount: displayNeeds, color: 'bg-purple-600', text: 'text-purple-400' },
                        { label: 'Gustos', amount: displayWants, color: 'bg-violet-600', text: 'text-violet-400' },
                        { label: 'Ahorros', amount: displaySavings, color: 'bg-teal-500', text: 'text-teal-400' }
                    ].map((cat, i) => {
                        const total = displayNeeds + displayWants + displaySavings || 1;
                        const percent = Math.round((cat.amount / total) * 100);
                        
                        return (
                            <div key={i} className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex items-center gap-4">
                                <div className={`w-1 h-12 rounded-full ${cat.color}`}></div>
                                <div className="flex-1">
                                    <div className="flex justify-between items-center mb-2">
                                        <span className="text-sm font-bold text-white">{cat.label}</span>
                                        <span className={`text-sm font-bold ${cat.text}`}>{formatCurrency(cat.amount)}</span>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                            <div className={`h-full rounded-full ${cat.color}`} style={{width: `${percent}%`}}></div>
                                        </div>
                                        <span className="text-[10px] text-gray-500 font-bold">{percent}%</span>
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>

        </div>

    </div>
  );
};