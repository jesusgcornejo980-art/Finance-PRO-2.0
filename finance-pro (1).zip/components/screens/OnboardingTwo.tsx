import React, { useEffect, useState } from 'react';
import { Trophy, TrendingDown, Wallet, Check, ChevronLeft } from 'lucide-react';
import { Button } from '../Button';

interface Props {
  onNext: () => void;
  onBack: () => void;
}

export const OnboardingTwo: React.FC<Props> = ({ onNext, onBack }) => {
  const [percentage, setPercentage] = useState(100);

  useEffect(() => {
    // Animation to count down from 100% to 0% (representing debt elimination)
    // Slower animation (4 seconds)
    const duration = 4000; 
    const steps = 100;
    const intervalTime = duration / steps;
    const decrement = 100 / steps;

    const timer = setInterval(() => {
      setPercentage(prev => {
        const next = prev - decrement;
        if (next <= 0) {
          clearInterval(timer);
          return 0;
        }
        return next;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex flex-col h-full bg-slate-950 relative overflow-hidden">
        <style>{`
            @keyframes fillBar {
                from { width: 0%; }
                to { width: 100%; }
            }
            .animate-fill-bar {
                animation: fillBar 4s ease-out forwards;
            }
            @keyframes float-trophy {
                0% { transform: translateY(0px) scale(1); filter: drop-shadow(0 0 15px rgba(168, 85, 247, 0.2)); }
                50% { transform: translateY(-12px) scale(1.05); filter: drop-shadow(0 0 30px rgba(217, 70, 239, 0.5)); }
                100% { transform: translateY(0px) scale(1); filter: drop-shadow(0 0 15px rgba(168, 85, 247, 0.2)); }
            }
            .animate-trophy {
                animation: float-trophy 3s ease-in-out infinite;
            }
        `}</style>

        {/* Back Button */}
        <button onClick={onBack} className="absolute top-6 left-6 z-30 w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center text-white hover:bg-slate-700 transition-colors">
            <ChevronLeft className="w-6 h-6" />
        </button>

      {/* Visual Container - Flexible to avoid overflow */}
      <div className="flex-1 flex flex-col items-center justify-center relative w-full min-h-0 py-2">
        {/* Glowing Circle Background */}
        <div className="relative w-[50%] max-w-[240px] aspect-square rounded-full border-2 border-purple-500/20 flex items-center justify-center shrink-1 scale-90 sm:scale-100 transition-transform">
            <div className="absolute w-[72%] h-[72%] rounded-full bg-slate-800/50 flex items-center justify-center shadow-[0_0_60px_rgba(139,92,246,0.3)] animate-trophy">
                <Trophy className="w-1/2 h-1/2 text-purple-200" />
            </div>
            {/* Progress Arc Simulation */}
            <svg className="absolute w-full h-full rotate-[-90deg]" viewBox="0 0 280 280">
                <circle cx="140" cy="140" r="138" stroke="currentColor" strokeWidth="2" fill="none" className="text-purple-600/30" />
                <circle cx="140" cy="140" r="138" stroke="currentColor" strokeWidth="4" fill="none" strokeDasharray="870" strokeDashoffset="350" className="text-fuchsia-500 drop-shadow-[0_0_10px_rgba(217,70,239,0.8)]" strokeLinecap="round" />
            </svg>
            <div className="absolute top-[5%] right-[10%] bg-fuchsia-500 rounded-full p-1 shadow-lg shadow-fuchsia-500/50 animate-bounce">
                <Check className="w-3 h-3 text-white" />
            </div>
        </div>
      </div>

        {/* Debt Progress Card */}
        <div className="px-6 relative z-20 -mt-8 mb-2 shrink-0">
            <div className="bg-slate-900/80 backdrop-blur border border-white/5 rounded-2xl p-4 shadow-xl max-w-sm mx-auto w-full">
                <div className="flex justify-between text-xs font-bold mb-2">
                    <span className="text-purple-300">DEUDA RESTANTE</span>
                    <span className="text-white">{Math.round(percentage)}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-violet-600 to-fuchsia-600 animate-fill-bar"></div>
                </div>
            </div>
        </div>

      {/* Content */}
      <div className="p-6 pt-0 pb-6 bg-slate-950 z-20 shrink-0 flex flex-col">
        <h2 className="text-3xl font-bold mb-4 leading-tight">
          Tu dinero bajo control, <br/>
          <span className="text-fuchsia-500">automáticamente</span>.
        </h2>
        
        <p className="text-gray-400 mb-6 leading-relaxed text-sm">
          Configura tus metas y deja que nuestro sistema <span className="text-fuchsia-400 font-bold">50-30-20</span> trabaje por ti.
        </p>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="bg-slate-900/50 border border-white/5 p-3 rounded-2xl flex flex-col items-center gap-2">
                <TrendingDown className="w-5 h-5 text-purple-400" />
                <span className="text-xs font-medium text-gray-300">Adiós Deudas</span>
            </div>
            <div className="bg-slate-900/50 border border-white/5 p-3 rounded-2xl flex flex-col items-center gap-2">
                <Wallet className="w-5 h-5 text-fuchsia-400" />
                <span className="text-xs font-medium text-gray-300">Meta Semanal</span>
            </div>
        </div>

        {/* Progress Dots */}
        <div className="flex items-center gap-2 mb-6">
            <div className="w-1.5 h-1.5 rounded-full bg-gray-700" />
            <div className="w-12 h-1.5 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500" />
            <div className="w-1.5 h-1.5 rounded-full bg-gray-700" />
            <span className="ml-auto text-[10px] font-bold text-fuchsia-500 tracking-widest uppercase">Auto-Pilot</span>
        </div>

        <Button onClick={onNext} showIcon>
          Continuar
        </Button>
      </div>
    </div>
  );
};