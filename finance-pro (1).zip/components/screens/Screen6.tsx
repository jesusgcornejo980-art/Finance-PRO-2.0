import React, { useState } from 'react';
import { 
  ChevronLeft, Shapes, Home, ShoppingCart, GripVertical, Pencil, Plus, 
  Car, Zap, Smartphone, Coffee, Utensils, Plane, Gift, Heart, Smile, 
  Briefcase, GraduationCap, Dumbbell, Shield, TrendingUp, Film, Music, X
} from 'lucide-react';
import { Button } from '../Button';
import { Reorder, useDragControls } from 'framer-motion';
import { Section } from '../../types';

interface Props {
  onBack: () => void;
  onFinish: () => void;
  sections: Section[];
  setSections: React.Dispatch<React.SetStateAction<Section[]>>;
  isEditMode?: boolean;
}

// Icon Registry for dynamic rendering
const ICON_MAP: Record<string, React.ElementType> = {
  'home': Home,
  'shopping-cart': ShoppingCart,
  'car': Car,
  'zap': Zap,
  'smartphone': Smartphone,
  'coffee': Coffee,
  'utensils': Utensils,
  'plane': Plane,
  'gift': Gift,
  'heart': Heart,
  'smile': Smile,
  'briefcase': Briefcase,
  'graduation-cap': GraduationCap,
  'dumbbell': Dumbbell,
  'shield': Shield,
  'trending-up': TrendingUp,
  'film': Film,
  'music': Music,
  'shapes': Shapes,
};

// Helper component for Reorder Item to isolate drag controls hooks
const SortableCategoryItem = ({ item, section, onEdit, IconComponent }: any) => {
  const dragControls = useDragControls();

  return (
    <Reorder.Item
      value={item}
      id={item.id}
      dragListener={false} // Disable dragging by default (enable only on handle)
      dragControls={dragControls}
      className="bg-surface border border-white/5 rounded-2xl p-3 flex items-center justify-between group relative select-none"
      whileDrag={{ scale: 1.02, boxShadow: "0px 8px 15px rgba(0,0,0,0.5)", zIndex: 50 }}
    >
      <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center ${section.color}`}>
              <IconComponent name={item.icon} className="w-5 h-5" />
          </div>
          <span className="font-medium text-sm text-white">{item.name}</span>
      </div>
      <div className="flex items-center gap-2 text-gray-500">
          <button 
              onClick={() => onEdit(section.id, item)}
              className="p-2 hover:bg-white/5 rounded-full hover:text-white transition-colors">
              <Pencil className="w-4 h-4" />
          </button>
          
          {/* Drag Handle */}
          <div 
            onPointerDown={(e) => dragControls.start(e)}
            className="cursor-grab p-2 hover:bg-white/5 rounded-full touch-none active:cursor-grabbing text-gray-600 hover:text-gray-400"
          >
             <GripVertical className="w-4 h-4" />
          </div>
      </div>
    </Reorder.Item>
  );
};

export const Screen6: React.FC<Props> = ({ onBack, onFinish, sections, setSections, isEditMode = false }) => {
  const [showIntroModal, setShowIntroModal] = useState(!isEditMode);
  
  // State for Editing/Adding
  const [editingItem, setEditingItem] = useState<{sectionId: string, itemId: string | null, name: string, icon: string} | null>(null);

  const handleEditClick = (sectionId: string, item: any) => {
    setEditingItem({
        sectionId,
        itemId: item.id,
        name: item.name,
        icon: item.icon
    });
  };

  const handleAddClick = (sectionId: string) => {
    setEditingItem({
        sectionId,
        itemId: null,
        name: '',
        icon: 'shapes'
    });
  };

  const handleSaveItem = () => {
    if (!editingItem) return;

    if (editingItem.itemId) {
        // Edit existing item
        setSections(prev => prev.map(section => {
            if (section.id !== editingItem.sectionId) return section;
            return {
                ...section,
                items: section.items.map(item => {
                    if (item.id !== editingItem.itemId) return item;
                    return { ...item, name: editingItem.name, icon: editingItem.icon };
                })
            };
        }));
    } else {
        // Add new item
        const newItem = {
            id: Date.now().toString(),
            name: editingItem.name || 'Nueva Categoría',
            icon: editingItem.icon
        };
        
        setSections(prev => prev.map(section => {
            if (section.id !== editingItem.sectionId) return section;
            return {
                ...section,
                items: [...section.items, newItem]
            };
        }));
    }
    setEditingItem(null);
  };

  const handleReorder = (sectionId: string, newItems: any[]) => {
    setSections(prev => prev.map(section => {
        if (section.id === sectionId) {
            return { ...section, items: newItems };
        }
        return section;
    }));
  };

  const IconComponent = ({ name, className }: { name: string, className?: string }) => {
    const Icon = ICON_MAP[name] || Shapes;
    return <Icon className={className} />;
  };

  return (
    <div className="flex flex-col h-full bg-black relative">
      
      {/* HEADER */}
      <div className="px-4 py-4 flex items-center justify-between bg-black/80 backdrop-blur-md sticky top-0 z-30 border-b border-white/5">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-gray-300 hover:text-white">
            <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-lg">Configurar Categorías</h2>
        <div className="w-10"></div>
      </div>

      {/* CONTENT LIST */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-32 no-scrollbar">
        {sections.map((section) => (
            <div key={section.id} className="animate-fade-in-up">
                <div className="flex justify-between items-center mb-2 px-1">
                    <span className={`text-xs font-bold tracking-widest ${section.color}`}>{section.title} ({section.percent})</span>
                    <span className="text-[10px] text-gray-600 uppercase">Fijo / Esencial</span>
                </div>

                <Reorder.Group 
                    axis="y" 
                    values={section.items} 
                    onReorder={(newItems) => handleReorder(section.id, newItems)}
                    className="space-y-2"
                >
                    {section.items.map((item) => (
                        <SortableCategoryItem 
                            key={item.id}
                            item={item}
                            section={section}
                            onEdit={handleEditClick}
                            IconComponent={IconComponent}
                        />
                    ))}
                </Reorder.Group>
                    
                {/* Add Button */}
                <button 
                    onClick={() => handleAddClick(section.id)}
                    className="w-full py-3 mt-2 rounded-2xl border border-dashed border-gray-800 text-gray-500 flex items-center justify-center gap-2 text-xs font-bold hover:bg-white/5 transition-colors active:scale-95">
                    <Plus className="w-4 h-4" /> AGREGAR
                </button>
            </div>
        ))}
      </div>

      {/* FOOTER */}
      <div className="p-4 pt-2 pb-6 bg-gradient-to-t from-black via-black to-transparent sticky bottom-0 z-30">
        <Button onClick={onFinish} showIcon={!isEditMode}>
            {isEditMode ? 'GUARDAR CAMBIOS' : 'SIGUIENTE'}
        </Button>
      </div>

      {/* EDIT/ADD MODAL */}
      {editingItem && (
        <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
             <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl relative overflow-hidden animate-slide-up">
                
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold">
                        {editingItem.itemId ? 'Editar Categoría' : 'Nueva Categoría'}
                    </h3>
                    <button onClick={() => setEditingItem(null)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <div className="space-y-6">
                    {/* Name Input */}
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Nombre</label>
                        <input 
                            type="text" 
                            placeholder="Ej. Transporte"
                            value={editingItem.name}
                            onChange={(e) => setEditingItem({...editingItem, name: e.target.value})}
                            className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500 transition-colors"
                            autoFocus
                        />
                    </div>

                    {/* Icon Picker */}
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 block">Icono</label>
                        <div className="grid grid-cols-6 gap-2">
                            {Object.keys(ICON_MAP).map((iconKey) => (
                                <button 
                                    key={iconKey}
                                    onClick={() => setEditingItem({...editingItem, icon: iconKey})}
                                    className={`aspect-square rounded-xl flex items-center justify-center transition-all ${
                                        editingItem.icon === iconKey 
                                        ? 'bg-purple-600 text-white shadow-lg scale-110' 
                                        : 'bg-slate-800 text-gray-400 hover:bg-slate-700'
                                    }`}
                                >
                                    <IconComponent name={iconKey} className="w-5 h-5" />
                                </button>
                            ))}
                        </div>
                    </div>

                    <Button onClick={handleSaveItem}>
                        {editingItem.itemId ? 'Guardar Cambios' : 'Agregar Categoría'}
                    </Button>
                </div>
             </div>
        </div>
      )}

      {/* INTRO MODAL */}
      {showIntroModal && (
        <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
            <div className="bg-surface border border-white/10 rounded-3xl p-6 w-full max-w-sm shadow-2xl relative overflow-hidden">
                {/* Modal Glow */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-purple-500"></div>
                <div className="absolute -top-20 -right-20 w-40 h-40 bg-purple-600/20 blur-[50px] rounded-full pointer-events-none"></div>

                <div className="flex justify-center mb-6 mt-4">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-900 border border-white/10 flex items-center justify-center shadow-lg">
                        <Shapes className="w-8 h-8 text-fuchsia-400" />
                    </div>
                </div>

                <h3 className="text-xl font-bold text-center mb-2">Personaliza tus Categorías</h3>
                
                <p className="text-center text-gray-400 text-sm mb-8 leading-relaxed">
                    Aquí puedes organizar tus gastos semanales. Edita los nombres o arrastra las tarjetas para que el presupuesto 50-30-20 se adapte a tu estilo de vida.
                </p>

                <Button onClick={() => setShowIntroModal(false)} variant="primary">
                    Entendido
                </Button>
            </div>
        </div>
      )}
    </div>
  );
};