import React, { useMemo } from 'react';
import { Button } from '../Button';
import { Bitcoin, Gem, ChevronLeft } from 'lucide-react';

interface Props {
  onNext: () => void;
  onBack?: () => void;
}

export const Screen2: React.FC<Props> = ({ onNext, onBack }) => {
  
  // Generate random background coins
  const backgroundCoins = useMemo(() => {
    return Array.from({ length: 50 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100, // Random horizontal position
      animationDuration: 15 + Math.random() * 20 + 's', // Slow falling speed (15-35s)
      animationDelay: -(Math.random() * 20) + 's', // Start at different times, negative to pre-fill screen
      symbol: ['$', '€', '£', '¥', '₿', '₽', '₩'][Math.floor(Math.random() * 7)],
      opacity: 0.05 + Math.random() * 0.1, // Very subtle opacity
      scale: 0.5 + Math.random() * 1, // Random sizes
    }));
  }, []);

  return (
    <div className="flex flex-col h-full bg-slate-950 relative">
       <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes float-reverse {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(8px); }
        }
        @keyframes fall {
            0% { transform: translateY(-10vh) rotate(0deg); }
            100% { transform: translateY(100vh) rotate(360deg); }
        }
        .animate-float { animation: float 4s ease-in-out infinite; }
        .animate-float-delayed { animation: float 5s ease-in-out infinite; animation-delay: 1s; }
        .animate-float-reverse { animation: float-reverse 6s ease-in-out infinite; }
        .animate-fall { animation: fall linear infinite; }
      `}</style>

      {/* Back Button */}
      {onBack && (
        <button onClick={onBack} className="absolute top-6 left-6 z-30 w-10 h-10 rounded-full bg-slate-800/50 flex items-center justify-center text-white hover:bg-slate-700 transition-colors">
            <ChevronLeft className="w-6 h-6" />
        </button>
      )}

      {/* Visual Container */}
      <div className="flex-1 relative flex items-center justify-center bg-gradient-to-b from-black to-slate-950 overflow-hidden">
        
        {/* Falling Currencies Background Layer */}
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
            {backgroundCoins.map((coin) => (
                <div
                    key={coin.id}
                    className="absolute -top-10 text-white font-serif font-bold animate-fall"
                    style={{
                        left: `${coin.left}%`,
                        animationDuration: coin.animationDuration,
                        animationDelay: coin.animationDelay,
                        opacity: coin.opacity,
                        fontSize: `${20 * coin.scale}px`,
                        willChange: 'transform',
                    }}
                >
                    {coin.symbol}
                </div>
            ))}
        </div>

        {/* Composition Container */}
        <div className="relative w-72 h-72 flex items-center justify-center z-10">
            
            {/* Background Glow */}
            <div className="absolute inset-0 bg-purple-600/20 blur-[80px] rounded-full" />
            
            {/* Background Chart Bars (Subtle) */}
            <div className="absolute bottom-12 left-0 right-0 flex justify-center items-end gap-3 opacity-20 z-0 px-10">
                <div className="w-4 h-16 bg-purple-500 rounded-t-lg"></div>
                <div className="w-4 h-24 bg-fuchsia-500 rounded-t-lg"></div>
                <div className="w-4 h-12 bg-indigo-500 rounded-t-lg"></div>
                <div className="w-4 h-20 bg-violet-500 rounded-t-lg"></div>
                <div className="w-4 h-8 bg-purple-400 rounded-t-lg"></div>
            </div>

            {/* Wallet Body (CSS 3D representation) - UPDATED COLOR: Purple Gradient Downwards */}
            <div className="relative z-10 w-44 h-32 bg-gradient-to-b from-purple-500 to-indigo-900 rounded-2xl border border-white/10 shadow-2xl flex items-center justify-center transform -rotate-3 animate-float">
                {/* Texture / Shine */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-black/20 to-white/10 pointer-events-none"></div>
                
                {/* Wallet Flap / Clasp */}
                <div className="absolute -right-1 top-1/2 -translate-y-1/2 w-8 h-12 bg-indigo-900 rounded-r-md rounded-l-sm border-y border-l border-white/5 flex items-center justify-center shadow-lg">
                    <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-br from-yellow-200 to-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.6)]"></div>
                </div>
                
                {/* Wallet Fold Line */}
                <div className="absolute left-2 top-2 bottom-2 w-[1px] bg-black/20"></div>
                
                {/* Inner Pocket hint */}
                <div className="w-32 h-1 bg-black/30 rounded-full mt-10"></div>
            </div>

            {/* Coin: MXN Symbol */}
            <div className="absolute bottom-14 left-4 z-20 animate-float-delayed">
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-violet-600 to-fuchsia-500 border-4 border-slate-950 shadow-[0_10px_30px_rgba(168,85,247,0.4)] flex flex-col items-center justify-center transform -rotate-6">
                    <span className="text-4xl font-bold text-white drop-shadow-md">$</span>
                </div>
            </div>

            {/* Coin: Bitcoin - Top Right, floating high - UPDATED STYLE */}
            <div className="absolute top-12 right-6 z-20 animate-float-reverse">
                <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-violet-600 to-fuchsia-500 border-2 border-slate-950 shadow-lg flex items-center justify-center transform rotate-12">
                     <Bitcoin className="w-6 h-6 text-white drop-shadow-md" />
                </div>
            </div>

            {/* Coin: Ethereum/Gem - Top Left, floating behind - UPDATED STYLE */}
            <div className="absolute top-16 left-8 z-0 animate-float">
                 <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-violet-600 to-fuchsia-500 border-2 border-slate-950 shadow-lg flex items-center justify-center transform -rotate-12">
                     <Gem className="w-4 h-4 text-white drop-shadow-md" />
                </div>
            </div>
            
        </div>
      </div>

      {/* Content */}
      <div className="p-6 pt-2 pb-8 bg-slate-950 relative z-30">
        <h2 className="text-3xl font-bold mb-4 leading-tight">
          Tu dinero bajo control, <br/>
          <span className="text-purple-500">automáticamente.</span>
        </h2>
        
        <p className="text-gray-400 mb-8 leading-relaxed text-sm">
          Activa tu billetera inteligente. La regla 50-30-20 organiza tus ingresos automáticamente desde el primer día.
        </p>

        {/* Progress Dots */}
        <div className="flex items-center gap-2 mb-6">
            <div className="w-12 h-1.5 rounded-full bg-gradient-to-r from-violet-600 to-violet-400" />
            <div className="w-1.5 h-1.5 rounded-full bg-gray-800" />
            <div className="w-1.5 h-1.5 rounded-full bg-gray-800" />
            <span className="ml-auto text-[10px] font-bold text-violet-500 tracking-widest uppercase">Smart Wallet</span>
        </div>

        <Button onClick={onNext} showIcon>
          SIGUIENTE
        </Button>
      </div>
    </div>
  );
};