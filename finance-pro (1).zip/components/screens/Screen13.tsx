import React, { useState, useMemo } from 'react';
import { Bell, CreditCard, ArrowLeftRight, Plus, Wallet, Home, BarChart3, X, Banknote, CircleDollarSign, Smartphone, ArrowDownLeft, ArrowUpRight, TrendingDown, TrendingUp, Landmark, User, Trash2, Pencil, Save, AlertTriangle, Check, Info, Lock } from 'lucide-react';
import { Button } from '../Button';
import { PaymentMethod, InternalTransfer, Transaction, Currency, Notification } from '../../types';

interface Props {
  methods: PaymentMethod[];
  setMethods: React.Dispatch<React.SetStateAction<PaymentMethod[]>>;
  onSaveMethod: (method: PaymentMethod) => void;
  transfers: InternalTransfer[];
  transactions: Transaction[]; 
  onTransfer: (fromId: number, toId: number, amount: number, commission: number) => void;
  onDeleteTransaction: (id: string) => void;
  onDeleteTransfer: (id: string) => void;
  onUpdateTransaction: (id: string, newAmount: number, newDescription: string) => void;
  onBackToBudget: () => void;
  onGoToAnalysis: () => void;
  onAddTransaction: () => void;
  onGoToProfile?: () => void;
  currency: Currency;
  notifications: Notification[];
  onOpenNotifications: () => void;
  onDismissNotification: (id: string) => void;
}

export const Screen13: React.FC<Props> = ({ 
    methods, 
    setMethods, 
    onSaveMethod,
    transfers, 
    transactions,
    onTransfer,
    onDeleteTransaction,
    onDeleteTransfer,
    onUpdateTransaction,
    onBackToBudget,
    onGoToAnalysis,
    onAddTransaction,
    onGoToProfile,
    currency,
    notifications,
    onOpenNotifications,
    onDismissNotification
}) => {
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [showMethodModal, setShowMethodModal] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);
  
  // Method Editing State
  const [editingMethod, setEditingMethod] = useState<PaymentMethod | null>(null);

  // Transfer State
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');

  // Movement Detail Modal State
  const [selectedMovement, setSelectedMovement] = useState<any | null>(null);
  const [isEditingMovement, setIsEditingMovement] = useState(false);
  const [editAmount, setEditAmount] = useState('');
  const [editDescription, setEditDescription] = useState('');

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleBellClick = () => {
      setShowNotificationsModal(true);
      if (unreadCount > 0) {
        onOpenNotifications();
      }
  };

  const handleCloseNotifications = () => {
      setShowNotificationsModal(false);
      setSelectedNotification(null);
  };

  const handleNotificationClick = (notif: Notification) => {
      setSelectedNotification(notif);
  };

  const handleBackFromDetail = () => {
      if (selectedNotification) {
          onDismissNotification(selectedNotification.id);
          setSelectedNotification(null);
      }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 2
    }).format(value);
  };

  const formatDate = (date: Date) => {
      return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  const allMovements = useMemo(() => {
    const mappedTransfers = transfers.map(t => ({
        id: t.id, // Keep raw ID for deletion
        uniqueId: `tr-${t.id}`,
        type: 'transfer' as const,
        amount: t.amount,
        date: t.date,
        title: 'Transferencia',
        subtitle: `De ${t.fromName} a ${t.toName}`,
        description: `Comisión: ${t.commission}`,
        icon: <ArrowLeftRight className="w-4 h-4 text-white" />,
        colorClass: 'bg-indigo-500/20 text-indigo-400',
        amountColor: 'text-white'
    }));

    const mappedTransactions = transactions.map(t => {
        let title = '';
        let subtitle = t.methodName;
        let icon;
        let colorClass;
        let amountColor;
        
        if (t.type === 'income') {
            title = t.isWeekStart ? 'Ingreso (Inicio Semana)' : 'Ingreso';
            icon = <TrendingUp className="w-4 h-4 text-emerald-400" />;
            colorClass = 'bg-emerald-500/20';
            amountColor = 'text-emerald-400';
        } else {
            if (t.isDebtPayment) {
                title = t.debtName ? `Pago a ${t.debtName}` : 'Pago de Deuda';
                icon = <Landmark className="w-4 h-4 text-fuchsia-400" />;
                colorClass = 'bg-fuchsia-500/20';
                amountColor = 'text-fuchsia-400';
            } else {
                title = t.categoryName || 'Gasto General';
                icon = <TrendingDown className="w-4 h-4 text-red-400" />;
                colorClass = 'bg-red-500/20';
                amountColor = 'text-white';
            }
        }

        return {
            id: t.id,
            uniqueId: `tx-${t.id}`,
            type: t.type,
            amount: t.amount,
            date: t.date,
            title,
            subtitle,
            description: t.description || 'Sin descripción',
            icon,
            colorClass,
            amountColor
        };
    });

    return [...mappedTransfers, ...mappedTransactions].sort((a, b) => b.date.getTime() - a.date.getTime());

  }, [transfers, transactions]);

  // --- METHODS LOGIC ---
  const handleEditMethod = (method: PaymentMethod) => {
      // Prevent editing if ReadOnly
      if (method.isReadOnly) return;
      
      setEditingMethod(method);
      setShowMethodModal(true);
  };

  const handleNewMethod = () => {
      setEditingMethod({
          id: Date.now(),
          name: '',
          subtitle: '',
          balance: '',
          type: 'debit',
          label: 'BALANCE'
      });
      setShowMethodModal(true);
  };

  const handleSaveMethod = () => {
      if (!editingMethod) return;
      onSaveMethod(editingMethod);
      setShowMethodModal(false);
      setEditingMethod(null);
  };
  
  const handleDeleteMethod = () => {
       if (!editingMethod) return;
       setMethods(prev => prev.filter(m => m.id !== editingMethod.id));
       setShowMethodModal(false);
       setEditingMethod(null);
  };

  // --- TRANSFER LOGIC ---
  const handleConfirmTransfer = () => {
      const fromId = parseInt(fromAccount);
      const toId = parseInt(toAccount);
      const amount = parseFloat(transferAmount);
      
      if (!fromId || !toId || !amount || fromId === toId) return;

      const origin = methods.find(m => m.id === fromId);
      let commission = 0;
      
      if (origin?.type === 'credit') {
          const destination = methods.find(m => m.id === toId);
          if (destination?.type === 'cash') commission = amount * 0.05; 
          else if (destination?.type === 'debit') commission = amount * 0.03; 
      }

      onTransfer(fromId, toId, amount, commission);
      setShowTransferModal(false);
      setFromAccount('');
      setToAccount('');
      setTransferAmount('');
  };

  const calculateCommission = () => {
      const fromId = parseInt(fromAccount);
      const toId = parseInt(toAccount);
      const amount = parseFloat(transferAmount);
      if (!fromId || !toId || !amount) return 0;
      
      const origin = methods.find(m => m.id === fromId);
      const destination = methods.find(m => m.id === toId);
      
      if (origin?.type === 'credit') {
          if (destination?.type === 'cash') return amount * 0.05;
          if (destination?.type === 'debit') return amount * 0.03;
      }
      return 0;
  };
  
  const commissionPreview = calculateCommission();

  const getCardGradient = (type: string, isReadOnly?: boolean) => {
      if (isReadOnly) return 'bg-gradient-to-br from-teal-900 via-emerald-900 to-slate-900 border-teal-500/30';
      if (type === 'credit') return 'bg-gradient-to-br from-indigo-900 via-purple-900 to-fuchsia-900 border-purple-500/30';
      if (type === 'debit') return 'bg-gradient-to-br from-slate-800 via-slate-900 to-black border-white/10';
      return 'bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 border-teal-500/30';
  };

  // --- DETAIL MODAL LOGIC ---
  const handleOpenMovement = (m: any) => {
      setSelectedMovement(m);
      setEditAmount(m.amount.toString());
      setEditDescription(m.description);
      setIsEditingMovement(false);
  };

  const handleDeleteCurrentMovement = () => {
      if (selectedMovement.type === 'transfer') {
          onDeleteTransfer(selectedMovement.id);
      } else {
          onDeleteTransaction(selectedMovement.id);
      }
      setSelectedMovement(null);
  };

  const handleUpdateCurrentMovement = () => {
      if (selectedMovement.type !== 'transfer') {
          onUpdateTransaction(selectedMovement.id, parseFloat(editAmount), editDescription);
      }
      setSelectedMovement(null);
  };

  return (
    <div className="flex flex-col h-full bg-black relative">
        
        {/* --- HEADER --- */}
        <div className="px-6 pt-10 pb-4 flex justify-between items-center z-10 sticky top-0 bg-black/90 backdrop-blur-md">
            <h1 className="text-2xl font-bold text-white">Gestión de Cuentas</h1>
            <button 
                onClick={handleBellClick}
                className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-fuchsia-500 hover:text-white transition-colors relative"
            >
                 <Bell className="w-5 h-5" />
                 {unreadCount > 0 && (
                     <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-fuchsia-500 border border-black animate-pulse"></div>
                 )}
            </button>
        </div>

        {/* --- CONTENT --- */}
        <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
            
            {/* 1. CARDS CAROUSEL */}
            <div className="flex gap-4 overflow-x-auto px-6 pb-6 no-scrollbar snap-x snap-mandatory">
                {methods.map(method => (
                    <div 
                        key={method.id}
                        onClick={() => handleEditMethod(method)}
                        className={`min-w-[280px] h-44 rounded-3xl p-6 relative flex flex-col justify-between shrink-0 snap-center border ${getCardGradient(method.type, method.isReadOnly)} shadow-2xl ${method.isReadOnly ? 'cursor-default' : 'cursor-pointer active:scale-95'} transition-transform`}
                    >
                         <div className="flex justify-between items-start">
                             <div>
                                 <p className="text-[10px] text-gray-300 font-bold uppercase tracking-widest opacity-80 mb-1">
                                     {method.isReadOnly ? 'AHORRO AUTOMÁTICO' : method.type === 'cash' ? 'EFECTIVO' : method.type === 'debit' ? 'DÉBITO PRINCIPAL' : 'CRÉDITO'}
                                 </p>
                                 <h3 className="text-lg font-bold text-white truncate max-w-[150px]">{method.name}</h3>
                             </div>
                             {method.isReadOnly ? (
                                 <div className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center">
                                     <Lock className="w-4 h-4 text-emerald-400" />
                                 </div>
                             ) : method.type !== 'cash' && (
                                 <div className="px-2 py-1 rounded bg-white/10 text-[10px] font-bold text-white tracking-wider border border-white/10">
                                     VISA
                                 </div>
                             )}
                         </div>
                         
                         <div>
                             <p className="text-[10px] text-gray-400 font-medium mb-1">Balance actual</p>
                             <p className="text-3xl font-bold text-white tracking-tight">{formatCurrency(parseFloat(method.balance))}</p>
                         </div>

                         <div className="flex justify-between items-center">
                             <div className="flex gap-1.5">
                                 <div className="w-1.5 h-1.5 rounded-full bg-white/40"></div>
                                 <div className="w-1.5 h-1.5 rounded-full bg-white/40"></div>
                                 <div className="w-1.5 h-1.5 rounded-full bg-white/40"></div>
                                 <span className="text-xs font-mono text-white/60 ml-1">4412</span>
                             </div>
                             <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                                 {method.type === 'cash' || method.isReadOnly ? <Banknote className="w-4 h-4 text-emerald-400" /> : <Smartphone className="w-4 h-4 text-fuchsia-400" />}
                             </div>
                         </div>
                    </div>
                ))}

                <button 
                    onClick={handleNewMethod}
                    className="min-w-[60px] h-44 rounded-3xl border-2 border-dashed border-white/10 flex flex-col items-center justify-center gap-2 text-gray-500 hover:text-white hover:border-white/30 transition-colors"
                >
                    <Plus className="w-6 h-6" />
                </button>
            </div>

            {/* 2. ACTION BUTTONS */}
            <div className="grid grid-cols-2 gap-4 px-6 mb-8">
                <button 
                    onClick={() => setShowTransferModal(true)}
                    className="aspect-[4/3] rounded-3xl bg-surface border border-white/5 flex flex-col items-center justify-center gap-3 hover:bg-white/5 transition-colors group"
                >
                    <div className="w-12 h-12 rounded-full bg-indigo-500/10 flex items-center justify-center group-hover:bg-indigo-500/20 transition-colors">
                        <ArrowLeftRight className="w-6 h-6 text-indigo-400" />
                    </div>
                    <span className="text-sm font-bold text-white text-center leading-tight">Nueva<br/>Transferencia</span>
                </button>

                <button 
                    onClick={handleNewMethod}
                    className="aspect-[4/3] rounded-3xl bg-surface border border-white/5 flex flex-col items-center justify-center gap-3 hover:bg-white/5 transition-colors group"
                >
                    <div className="w-12 h-12 rounded-full bg-fuchsia-500/10 flex items-center justify-center group-hover:bg-fuchsia-500/20 transition-colors">
                        <CreditCard className="w-6 h-6 text-fuchsia-400" />
                    </div>
                    <span className="text-sm font-bold text-white text-center leading-tight">Añadir<br/>Método</span>
                </button>
            </div>

            {/* 3. MOVEMENTS LIST (Unified) */}
            <div className="px-6">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-bold text-white">Movimientos</h2>
                    <button className="text-xs font-bold text-fuchsia-500 hover:text-white transition-colors">Ver todos</button>
                </div>

                <div className="space-y-3">
                    {allMovements.length > 0 ? allMovements.map(m => (
                        <div 
                            key={m.uniqueId} 
                            onClick={() => handleOpenMovement(m)}
                            className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex items-center justify-between animate-fade-in-up cursor-pointer hover:bg-white/5 transition-colors"
                        >
                            <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${m.colorClass}`}>
                                    {m.icon}
                                </div>
                                <div>
                                    <p className="text-sm font-bold text-white">{m.title}</p>
                                    <p className="text-[10px] text-gray-500 truncate max-w-[150px]">{m.subtitle}</p>
                                    <p className="text-[9px] text-gray-600 mt-0.5">{formatDate(m.date)}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className={`text-sm font-bold ${m.amountColor}`}>
                                    {m.type === 'income' ? '+' : m.type === 'transfer' ? '' : '-'}{formatCurrency(m.amount)}
                                </p>
                                <p className="text-[9px] text-gray-500 font-bold uppercase">{m.type === 'transfer' ? 'TRANSFER' : m.type === 'income' ? 'INGRESO' : 'GASTO'}</p>
                            </div>
                        </div>
                    )) : (
                        <div className="text-center py-8 text-gray-500 text-xs border border-white/5 rounded-2xl bg-surface/30">
                            No hay movimientos registrados recientes
                        </div>
                    )}
                </div>
            </div>

        </div>

        {/* --- BOTTOM NAVIGATION BAR --- */}
        <div className="absolute bottom-0 left-0 w-full h-24 bg-black/90 backdrop-blur-xl border-t border-white/5 flex items-start justify-between px-6 pt-4 z-50">
          
          <button onClick={onBackToBudget} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors">
             <Home className="w-6 h-6" />
             <span className="text-[10px] font-medium">Presupuesto</span>
          </button>

          <button onClick={onGoToAnalysis} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <BarChart3 className="w-6 h-6" />
             <span className="text-[10px] font-medium">Análisis</span>
          </button>

          <button 
            onClick={onAddTransaction}
            className="w-16 h-16 -mt-8 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center shadow-[0_0_20px_rgba(192,38,211,0.4)] border-4 border-black active:scale-95 transition-transform"
          >
             <Plus className="w-8 h-8 text-white stroke-[3]" />
          </button>

          <button className="flex flex-col items-center gap-1 text-fuchsia-500 mt-1 cursor-default">
             <div className="p-1 rounded-xl bg-fuchsia-500/10">
                <CreditCard className="w-6 h-6" />
             </div>
             <span className="text-[10px] font-bold">Cuentas</span>
          </button>

          <button onClick={onGoToProfile} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <User className="w-6 h-6" />
             <span className="text-[10px] font-medium">Perfil</span>
          </button>

        </div>

        {/* --- TRANSFER MODAL --- */}
        {showTransferModal && (
             <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
                 <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl animate-slide-up max-h-[90vh] overflow-y-auto no-scrollbar">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-white">Nueva Transferencia</h3>
                        <button onClick={() => setShowTransferModal(false)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="space-y-4">
                        {/* FROM */}
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">De (Origen)</label>
                            <select 
                                value={fromAccount}
                                onChange={(e) => setFromAccount(e.target.value)}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500"
                            >
                                <option value="">Seleccionar cuenta...</option>
                                {methods.map(m => (
                                    <option key={m.id} value={m.id}>{m.name} ({m.type.toUpperCase()}) - ${m.balance}</option>
                                ))}
                            </select>
                        </div>

                        {/* TO */}
                        <div>
                             <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Para (Destino)</label>
                            <select 
                                value={toAccount}
                                onChange={(e) => setToAccount(e.target.value)}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500"
                            >
                                <option value="">Seleccionar cuenta...</option>
                                {methods.filter(m => m.id.toString() !== fromAccount).map(m => (
                                    <option key={m.id} value={m.id}>{m.name} ({m.type.toUpperCase()})</option>
                                ))}
                            </select>
                        </div>

                        {/* AMOUNT */}
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Monto a transferir</label>
                            <div className="relative">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                                <input 
                                    type="number"
                                    value={transferAmount}
                                    onChange={(e) => setTransferAmount(e.target.value)}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 pl-8 text-white focus:outline-none focus:border-purple-500 font-bold"
                                    placeholder="0.00"
                                />
                            </div>
                        </div>

                        {/* INFO BOX */}
                        {commissionPreview > 0 && (
                            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 flex items-start gap-3">
                                <div className="p-1 bg-yellow-500/20 rounded-full">
                                    <CircleDollarSign className="w-4 h-4 text-yellow-500" />
                                </div>
                                <div>
                                    <p className="text-xs font-bold text-yellow-500 mb-0.5">Aplica Comisión</p>
                                    <p className="text-[10px] text-yellow-200/70">
                                        Se cobrará una comisión de {formatCurrency(commissionPreview)} por esta operación.
                                    </p>
                                </div>
                            </div>
                        )}

                        <Button onClick={handleConfirmTransfer} disabled={!fromAccount || !toAccount || !transferAmount}>
                            CONFIRMAR TRANSFERENCIA
                        </Button>
                    </div>
                 </div>
             </div>
        )}

        {/* --- MOVEMENT DETAIL MODAL --- */}
        {selectedMovement && (
            <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
                <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl animate-slide-up relative overflow-hidden max-h-[90vh] overflow-y-auto no-scrollbar">
                    
                    {/* Header */}
                    <div className="flex justify-between items-start mb-6">
                        <div className="flex items-center gap-4">
                            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${selectedMovement.colorClass}`}>
                                {selectedMovement.icon}
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-white">{selectedMovement.title}</h3>
                                <p className="text-xs text-gray-400">{formatDate(selectedMovement.date)}</p>
                            </div>
                        </div>
                        <button onClick={() => setSelectedMovement(null)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    {/* Body */}
                    <div className="space-y-5">
                        
                        {/* Amount */}
                        <div className="bg-[#12121a] rounded-2xl p-4 border border-white/5 text-center">
                            <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">Monto</p>
                            {isEditingMovement ? (
                                <div className="relative inline-block w-full max-w-[200px]">
                                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500 font-bold">$</span>
                                    <input 
                                        type="number" 
                                        value={editAmount}
                                        onChange={(e) => setEditAmount(e.target.value)}
                                        className="bg-transparent text-3xl font-bold text-white text-center w-full focus:outline-none border-b border-purple-500 pb-1"
                                    />
                                </div>
                            ) : (
                                <p className={`text-3xl font-bold ${selectedMovement.amountColor}`}>
                                    {selectedMovement.type === 'income' ? '+' : selectedMovement.type === 'transfer' ? '' : '-'}{formatCurrency(selectedMovement.amount)}
                                </p>
                            )}
                        </div>

                        {/* Details */}
                        <div className="space-y-3">
                            <div className="flex justify-between items-center border-b border-white/5 pb-3">
                                <span className="text-xs text-gray-500">Método / Cuenta</span>
                                <span className="text-sm font-bold text-white">{selectedMovement.subtitle}</span>
                            </div>
                            <div className="flex justify-between items-center border-b border-white/5 pb-3">
                                <span className="text-xs text-gray-500">Descripción</span>
                                {isEditingMovement ? (
                                    <input 
                                        type="text" 
                                        value={editDescription}
                                        onChange={(e) => setEditDescription(e.target.value)}
                                        className="bg-slate-900 border border-white/10 rounded px-2 py-1 text-sm text-right text-white focus:border-purple-500 w-[60%]"
                                    />
                                ) : (
                                    <span className="text-sm font-medium text-gray-300 max-w-[60%] text-right truncate">
                                        {selectedMovement.description}
                                    </span>
                                )}
                            </div>
                            <div className="flex justify-between items-center pb-1">
                                <span className="text-xs text-gray-500">ID Transacción</span>
                                <span className="text-[10px] font-mono text-gray-600">#{selectedMovement.id}</span>
                            </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-3 pt-4">
                            {isEditingMovement ? (
                                <Button onClick={handleUpdateCurrentMovement} className="flex-1">
                                    <Save className="w-4 h-4" /> GUARDAR
                                </Button>
                            ) : (
                                <>
                                    {/* Edit Button (Only for transactions, transfers are complex to edit) */}
                                    {selectedMovement.type !== 'transfer' && (
                                        <button 
                                            onClick={() => setIsEditingMovement(true)}
                                            className="flex-1 py-4 rounded-2xl bg-slate-800 text-white font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-700 transition-colors"
                                        >
                                            <Pencil className="w-4 h-4" /> EDITAR
                                        </button>
                                    )}
                                    
                                    <button 
                                        onClick={handleDeleteCurrentMovement}
                                        className="flex-1 py-4 rounded-2xl bg-red-500/10 text-red-500 border border-red-500/20 font-bold text-sm flex items-center justify-center gap-2 hover:bg-red-500/20 transition-colors"
                                    >
                                        <Trash2 className="w-4 h-4" /> ELIMINAR
                                    </button>
                                </>
                            )}
                        </div>
                        
                        {!isEditingMovement && (
                            <p className="text-[9px] text-center text-gray-600 mt-2">
                                Eliminar este movimiento revertirá automáticamente los saldos afectados.
                            </p>
                        )}
                    </div>
                </div>
            </div>
        )}

        {/* --- METHOD MODAL (Add/Edit) --- */}
        {showMethodModal && editingMethod && (
             <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
                 <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl animate-slide-up max-h-[90vh] overflow-y-auto no-scrollbar">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-white">
                            {methods.some(m => m.id === editingMethod.id) ? 'Editar Método' : 'Nuevo Método'}
                        </h3>
                        <button onClick={() => setShowMethodModal(false)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="space-y-4">
                         {/* Type */}
                         <div className="grid grid-cols-3 gap-2">
                             {['cash', 'debit', 'credit'].map((t) => (
                                <button
                                    key={t}
                                    onClick={() => setEditingMethod({...editingMethod, type: t as any, label: t === 'credit' ? 'DISPONIBLE' : 'BALANCE'})}
                                    className={`py-2 rounded-xl text-[10px] font-bold uppercase border transition-colors ${
                                        editingMethod.type === t 
                                        ? 'bg-purple-600 border-purple-600 text-white' 
                                        : 'bg-transparent border-white/10 text-gray-400 hover:bg-white/5'
                                    }`}
                                >
                                    {t === 'cash' ? 'Efectivo' : t === 'debit' ? 'Débito' : 'Crédito'}
                                </button>
                             ))}
                         </div>
                         
                         <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Nombre</label>
                            <input 
                                type="text"
                                value={editingMethod.name}
                                onChange={(e) => setEditingMethod({...editingMethod, name: e.target.value})}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500"
                                placeholder="Ej. Visa Oro"
                            />
                         </div>
                         
                         <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Balance / Disponible</label>
                            <input 
                                type="number"
                                value={editingMethod.balance}
                                onChange={(e) => setEditingMethod({...editingMethod, balance: e.target.value})}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500"
                                placeholder="0.00"
                            />
                         </div>

                         <div className="pt-2 space-y-3">
                             <Button onClick={handleSaveMethod}>GUARDAR</Button>
                             {methods.some(m => m.id === editingMethod.id) && (
                                 <button onClick={handleDeleteMethod} className="w-full py-3 text-red-500 font-bold text-sm bg-red-500/10 rounded-xl hover:bg-red-500/20">
                                     ELIMINAR MÉTODO
                                 </button>
                             )}
                         </div>
                    </div>
                 </div>
             </div>
        )}

      {/* --- NOTIFICATIONS MODAL --- */}
      {showNotificationsModal && (
          <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
              <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl animate-slide-up max-h-[85vh] overflow-y-auto no-scrollbar relative">
                  
                  {/* Modal Header */}
                  <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-white">
                            {selectedNotification ? 'Detalle de Notificación' : 'Notificaciones'}
                        </h3>
                        <button onClick={handleCloseNotifications} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                  </div>

                  {/* Modal Content */}
                  <div className="space-y-4">
                      {selectedNotification ? (
                          // DETAIL VIEW
                          <div className="animate-fade-in">
                              <div className={`p-6 rounded-3xl border border-white/5 flex flex-col items-center text-center gap-4 ${
                                   selectedNotification.type === 'warning' ? 'bg-yellow-500/10' :
                                   selectedNotification.type === 'success' ? 'bg-emerald-500/10' :
                                   'bg-blue-500/10'
                              }`}>
                                   <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                                       selectedNotification.type === 'warning' ? 'bg-yellow-500/20 text-yellow-500' :
                                       selectedNotification.type === 'success' ? 'bg-emerald-500/20 text-emerald-500' :
                                       'bg-blue-500/20 text-blue-500'
                                   }`}>
                                       {selectedNotification.type === 'warning' ? <AlertTriangle className="w-8 h-8" /> :
                                        selectedNotification.type === 'success' ? <Check className="w-8 h-8" /> :
                                        <Info className="w-8 h-8" />
                                       }
                                   </div>
                                   <div>
                                       <h4 className="text-lg font-bold text-white mb-2">{selectedNotification.title}</h4>
                                       <p className="text-sm text-gray-300 leading-relaxed mb-4">{selectedNotification.message}</p>
                                       <p className="text-xs text-gray-500 font-bold">{formatDate(selectedNotification.date)}</p>
                                   </div>
                              </div>
                              
                              <div className="mt-6">
                                  <Button onClick={handleBackFromDetail} showIcon={false}>
                                      COMPRENDIDO / ARCHIVAR
                                  </Button>
                              </div>
                          </div>
                      ) : (
                          // LIST VIEW
                          notifications.length > 0 ? (
                              notifications.map((notif) => (
                                  <div 
                                    key={notif.id} 
                                    onClick={() => handleNotificationClick(notif)}
                                    className={`p-4 rounded-2xl border ${notif.read ? 'bg-black/20 border-white/5' : 'bg-surface border-purple-500/20'} flex items-start gap-4 cursor-pointer hover:bg-white/5 transition-colors`}
                                  >
                                       <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                                           notif.type === 'warning' ? 'bg-yellow-500/10 text-yellow-500' :
                                           notif.type === 'success' ? 'bg-emerald-500/10 text-emerald-500' :
                                           'bg-blue-500/10 text-blue-500'
                                       }`}>
                                           {notif.type === 'warning' ? <AlertTriangle className="w-5 h-5" /> :
                                            notif.type === 'success' ? <Check className="w-5 h-5" /> :
                                            <Info className="w-5 h-5" />
                                           }
                                       </div>
                                       <div className="flex-1">
                                           <div className="flex justify-between items-start">
                                                <h4 className={`text-sm font-bold ${notif.read ? 'text-gray-300' : 'text-white'}`}>{notif.title}</h4>
                                                {!notif.read && <div className="w-2 h-2 rounded-full bg-fuchsia-500 mt-1"></div>}
                                           </div>
                                           <p className="text-xs text-gray-400 mt-1 leading-relaxed line-clamp-2">{notif.message}</p>
                                           <p className="text-[10px] text-gray-600 mt-2 font-medium">{formatDate(notif.date)}</p>
                                       </div>
                                  </div>
                              ))
                          ) : (
                              <div className="py-10 text-center text-gray-500">
                                  <p>No tienes notificaciones nuevas.</p>
                              </div>
                          )
                      )}
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};