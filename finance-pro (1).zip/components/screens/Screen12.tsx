import React from 'react';
import { User, Wallet, BarChart3, Plus, CreditCard, Home, ArrowUpRight, ArrowDownRight, TrendingUp, CircleDollarSign, Banknote } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Label } from 'recharts';
import { DebtItem, PaymentMethod, Currency } from '../../types';

interface Props {
  weeklyBalance: number;
  spentAmounts: { needs: number; savings: number; wants: number };
  debts: DebtItem[];
  methods: PaymentMethod[];
  onAddTransaction: () => void;
  onBackToBudget: () => void;
  onViewDetailedAnalysis?: () => void;
  onGoToCards?: () => void;
  onGoToProfile?: () => void;
  currency: Currency;
}

export const Screen12: React.FC<Props> = ({ 
    weeklyBalance, 
    spentAmounts, 
    debts, 
    methods, 
    onAddTransaction,
    onBackToBudget,
    onViewDetailedAnalysis,
    onGoToCards,
    onGoToProfile,
    currency
}) => {

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 2
    }).format(value);
  };

  // --- Calculations ---
  
  // 1. Total Balance (Sum of all payment methods balances)
  const totalGlobalBalance = methods.reduce((acc, curr) => {
      if (curr.type === 'credit') return acc; 
      return acc + (parseFloat(curr.balance) || 0);
  }, 0);

  // 2. Weekly Income vs Expense
  const totalSpent = spentAmounts.needs + spentAmounts.savings + spentAmounts.wants;
  const approximateWeeklyIncome = weeklyBalance + totalSpent;

  // 3. Budget Health (50-30-20)
  const totalBudget = approximateWeeklyIncome > 0 ? approximateWeeklyIncome : 1; // Avoid div by 0
  const totalRemainingPercent = Math.max(0, Math.round(((weeklyBalance) / totalBudget) * 100));
  
  // Actually, to match the visual (Rainbow ring), we can plot the 3 categories + remaining
  const healthData = [
      { name: 'Necesidades', value: spentAmounts.needs, color: '#9333ea' }, // purple-600
      { name: 'Gustos', value: spentAmounts.wants, color: '#8b5cf6' }, // violet-500
      { name: 'Ahorros', value: spentAmounts.savings, color: '#2dd4bf' }, // teal-400 (using teal for differentiation like image)
      { name: 'Restante', value: weeklyBalance > 0 ? weeklyBalance : 1, color: '#1f2937' }, // gray-800 (background/empty) - use 1 to prevent empty chart if balance is 0 but expenses are 0 too
  ];
  
  // Adjust health data if everything is 0 to show empty chart (gray ring)
  if (totalSpent === 0 && weeklyBalance === 0) {
      healthData.forEach(d => { if(d.name !== 'Restante') d.value = 0; });
      healthData.find(d => d.name === 'Restante')!.value = 1;
  }

  // 4. Debt Progress
  const totalInitialDebt = debts.reduce((acc, d) => acc + (parseFloat(d.initial) || 0), 0);
  const totalCurrentDebt = debts.reduce((acc, d) => acc + (parseFloat(d.current) || 0), 0);
  const totalPaidDebt = totalInitialDebt - totalCurrentDebt;
  const debtProgress = totalInitialDebt > 0 ? (totalPaidDebt / totalInitialDebt) * 100 : 0;


  return (
    <div className="flex flex-col h-full bg-black relative">
        
        {/* --- HEADER --- */}
        <div className="px-6 pt-10 pb-4 flex justify-between items-center z-10">
            <div>
                <span className="text-xs font-bold text-fuchsia-500 tracking-widest uppercase mb-1 block">RESUMEN PREMIUM</span>
                <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-800 to-fuchsia-800 border border-white/20 flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
            </div>
        </div>

        {/* --- CONTENT --- */}
        <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-32 space-y-4">
            
            {/* 1. TOTAL BALANCE CARD */}
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-6 relative overflow-hidden shadow-2xl">
                {/* Glow effects */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 blur-[50px] rounded-full pointer-events-none"></div>
                
                <div className="text-center relative z-10">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">BALANCE TOTAL</p>
                    <h2 className="text-4xl font-bold text-white mb-2">
                        {formatCurrency(totalGlobalBalance)}
                        <span className="text-gray-500 text-2xl"></span>
                    </h2>
                    <div className="inline-flex items-center gap-1 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                        <TrendingUp className="w-3 h-3 text-emerald-400" />
                        <span className="text-xs font-bold text-emerald-400">+0.0% esta semana</span>
                    </div>
                </div>
            </div>

            {/* 2. INCOME vs EXPENSE ROW */}
            <div className="grid grid-cols-2 gap-4">
                {/* Income */}
                <div className="bg-[#12121a] border border-white/5 rounded-3xl p-5 relative overflow-hidden">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-4">
                        <ArrowDownRight className="w-5 h-5 text-emerald-400" />
                    </div>
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wide mb-1">Ingreso Semanal</p>
                    <p className="text-xl font-bold text-white">{formatCurrency(approximateWeeklyIncome)}</p>
                </div>
                {/* Expense */}
                <div className="bg-[#12121a] border border-white/5 rounded-3xl p-5 relative overflow-hidden">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center mb-4">
                        <ArrowUpRight className="w-5 h-5 text-purple-400" />
                    </div>
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wide mb-1">Gasto Semanal</p>
                    <p className="text-xl font-bold text-purple-400">{formatCurrency(totalSpent)}</p>
                </div>
            </div>

            {/* 3. BUDGET HEALTH (Donut Chart) */}
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-6">
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-6">SALUD DEL PRESUPUESTO (50-30-20)</p>
                
                <div className="flex items-center justify-between">
                    {/* Chart */}
                    <div className="w-32 h-32 relative shrink-0">
                         <ResponsiveContainer width="100%" height="100%">
                            <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
                                <Pie
                                    data={healthData}
                                    innerRadius={40}
                                    outerRadius={55}
                                    paddingAngle={5}
                                    dataKey="value"
                                    cornerRadius={4}
                                    stroke="none"
                                >
                                    {healthData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                    ))}
                                </Pie>
                            </PieChart>
                        </ResponsiveContainer>
                        {/* Center Text */}
                        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <span className="text-[9px] text-gray-500 uppercase">Restante</span>
                            <span className="text-lg font-bold text-white">{totalRemainingPercent}%</span>
                        </div>
                    </div>

                    {/* Legend */}
                    <div className="space-y-3 flex-1 pl-6">
                        <div className="flex justify-between items-center">
                             <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full bg-purple-600"></div>
                                <span className="text-[10px] text-gray-400 font-bold uppercase">Necesidades</span>
                             </div>
                             <span className="text-xs font-bold text-white">{formatCurrency(spentAmounts.needs)}</span>
                        </div>
                         <div className="flex justify-between items-center">
                             <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full bg-violet-500"></div>
                                <span className="text-[10px] text-gray-400 font-bold uppercase">Gustos</span>
                             </div>
                             <span className="text-xs font-bold text-white">{formatCurrency(spentAmounts.wants)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                             <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full bg-teal-400"></div>
                                <span className="text-[10px] text-gray-400 font-bold uppercase">Ahorros</span>
                             </div>
                             <span className="text-xs font-bold text-white">{formatCurrency(spentAmounts.savings)}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* 4. DEBT PAYMENT PROGRESS */}
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-6">
                 <div className="flex justify-between items-center mb-1">
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">PAGO DE DEUDAS</p>
                    <span className="text-lg font-bold text-fuchsia-400">{Math.round(debtProgress)}%</span>
                 </div>
                 <p className="text-[10px] text-gray-600 mb-4">Meta: Libertad Total para Dic 2025</p>

                 <div className="h-3 w-full bg-slate-800/50 rounded-full overflow-hidden mb-2">
                    <div 
                        className="h-full bg-gradient-to-r from-purple-600 to-fuchsia-600 shadow-[0_0_15px_rgba(192,38,211,0.5)]"
                        style={{ width: `${debtProgress}%` }}
                    ></div>
                 </div>
                 
                 <div className="flex justify-between text-[9px] text-gray-500 font-bold uppercase mt-2">
                    <span>Pagado: {formatCurrency(totalPaidDebt)}</span>
                    <span>Restante: {formatCurrency(totalCurrentDebt)}</span>
                 </div>
            </div>

            {/* 5. WEEKLY PULSE (Mock Chart) */}
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-6">
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-6">PULSO SEMANAL</p>
                
                <div className="space-y-3">
                    {/* Mock Data Bars - Set to 0 initial state */}
                    {[
                        { day: 'LUN', val: 0, max: 100 },
                        { day: 'MAR', val: 0, max: 100 },
                        { day: 'MIÉ', val: 0, max: 100 },
                        { day: 'JUE', val: 0, max: 100 },
                        { day: 'VIE', val: 0, max: 100 },
                    ].map((d, i) => (
                        <div key={i} className="flex items-center gap-3">
                            <span className="text-[9px] text-gray-500 font-bold w-6">{d.day}</span>
                            <div className="flex-1 h-2 bg-slate-800/50 rounded-full">
                                <div 
                                    className={`h-full rounded-full ${d.val > 0 ? 'bg-fuchsia-500 shadow-[0_0_8px_rgba(217,70,239,0.5)]' : 'bg-transparent'}`}
                                    style={{ width: `${d.max > 0 ? (d.val / d.max) * 100 : 0}%` }}
                                ></div>
                            </div>
                            <span className="text-[9px] text-gray-300 font-bold w-8 text-right">${d.val}</span>
                        </div>
                    ))}
                </div>

                <button 
                    onClick={onViewDetailedAnalysis}
                    className="w-full mt-6 py-4 rounded-xl border border-white/10 text-xs font-bold text-white hover:bg-white/5 transition-colors flex items-center justify-center gap-2"
                >
                    VER ANÁLISIS DETALLADO
                    <TrendingUp className="w-3 h-3 text-purple-400" />
                </button>
            </div>

             {/* 6. PAYMENT METHODS SCROLL */}
             <div className="pb-4">
                <div className="flex justify-between items-center mb-4 px-1">
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">MÉTODOS DE PAGO</p>
                    <button className="text-[10px] text-fuchsia-500 font-bold uppercase">VER TODO</button>
                </div>
                
                {methods.length > 0 ? (
                    <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
                        {methods.map(method => (
                            <div key={method.id} className="min-w-[140px] bg-[#12121a] border border-white/5 rounded-2xl p-4 flex flex-col justify-between h-32">
                                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${method.type === 'cash' ? 'bg-purple-500/10 text-purple-400' : 'bg-teal-500/10 text-teal-400'}`}>
                                    {method.type === 'cash' ? <Banknote className="w-4 h-4" /> : <Wallet className="w-4 h-4" />}
                                </div>
                                <div>
                                    <p className="text-[9px] text-gray-500 font-bold uppercase mb-1">{method.type}</p>
                                    <p className="text-sm font-bold text-white">{formatCurrency(parseFloat(method.balance))}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-4 border border-white/5 rounded-2xl bg-surface/30">
                        <p className="text-xs text-gray-500">No hay métodos registrados</p>
                    </div>
                )}
             </div>

        </div>

      {/* --- BOTTOM NAVIGATION BAR --- */}
      <div className="absolute bottom-0 left-0 w-full h-24 bg-black/90 backdrop-blur-xl border-t border-white/5 flex items-start justify-between px-6 pt-4 z-50">
          
          <button onClick={onBackToBudget} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors">
             <Home className="w-6 h-6" />
             <span className="text-[10px] font-medium">Presupuesto</span>
          </button>

          {/* Analysis button updated: Removed onClick to disable navigation to 12.1 from here */}
          <button className="flex flex-col items-center gap-1 text-fuchsia-500 mt-1 cursor-default">
            <div className="p-1 rounded-xl bg-fuchsia-500/10">
                <BarChart3 className="w-6 h-6" />
            </div>
             <span className="text-[10px] font-bold">Análisis</span>
          </button>

          {/* Floating Action Button */}
          <button 
            onClick={onAddTransaction}
            className="w-16 h-16 -mt-8 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center shadow-[0_0_20px_rgba(192,38,211,0.4)] border-4 border-black active:scale-95 transition-transform"
          >
             <Plus className="w-8 h-8 text-white stroke-[3]" />
          </button>

          <button onClick={onGoToCards} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <CreditCard className="w-6 h-6" />
             <span className="text-[10px] font-medium">Cuentas</span>
          </button>

          <button onClick={onGoToProfile} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <User className="w-6 h-6" />
             <span className="text-[10px] font-medium">Perfil</span>
          </button>

      </div>
    </div>
  );
};