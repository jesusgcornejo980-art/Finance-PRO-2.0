import React, { useState } from 'react';
import { ChevronLeft, Plus, CreditCard, Store, Car, Wallet, X, Home, GraduationCap, Banknote, Landmark, Percent } from 'lucide-react';
import { Button } from '../Button';

interface Props {
  onBack: () => void;
  onFinish: () => void;
}

// Icon Registry
const ICON_MAP: Record<string, React.ElementType> = {
  'credit-card': CreditCard,
  'store': Store,
  'car': Car,
  'home': Home,
  'graduation-cap': GraduationCap,
  'banknote': Banknote,
  'landmark': Landmark,
  'percent': Percent,
  'wallet': Wallet
};

interface DebtItem {
  id: number;
  name: string;
  subtitle: string;
  initial: string;
  current: string;
  minPay: string;
  icon: string;
}

export const DebtConfig: React.FC<Props> = ({ onBack, onFinish }) => {
  const [showIntroModal, setShowIntroModal] = useState(true);
  const [editingDebt, setEditingDebt] = useState<DebtItem | null>(null);

  // Initial State with some sample data
  const [debts, setDebts] = useState<DebtItem[]>([
    {
      id: 1,
      name: 'Tarjeta de Crédito',
      subtitle: 'Corte el 15 de cada mes',
      initial: '45000',
      current: '15750',
      minPay: '1200',
      icon: 'credit-card',
    },
    {
      id: 2,
      name: 'Préstamo Comercial',
      subtitle: 'Vence el 28 de cada mes',
      initial: '8500',
      current: '6630',
      minPay: '450',
      icon: 'store',
    },
    {
      id: 3,
      name: 'Financiamiento Auto',
      subtitle: 'Vence el 05 de cada mes',
      initial: '280000',
      current: '168000',
      minPay: '5400',
      icon: 'car',
    }
  ]);

  const handleEdit = (debt: DebtItem) => {
    setEditingDebt({ ...debt });
  };

  const handleAddNew = () => {
    setEditingDebt({
      id: Date.now(),
      name: '',
      subtitle: '',
      initial: '',
      current: '',
      minPay: '',
      icon: 'credit-card'
    });
  };

  const handleSave = () => {
    if (!editingDebt) return;

    setDebts(prev => {
      const exists = prev.find(d => d.id === editingDebt.id);
      if (exists) {
        return prev.map(d => d.id === editingDebt.id ? editingDebt : d);
      } else {
        return [...prev, editingDebt];
      }
    });
    setEditingDebt(null);
  };

  const deleteDebt = () => {
    if(!editingDebt) return;
    setDebts(prev => prev.filter(d => d.id !== editingDebt.id));
    setEditingDebt(null);
  }

  // Helper to format currency
  const formatCurrency = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return '$0';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(num);
  };

  // Helper to calculate percentage and color
  const getDebtStats = (initial: string, current: string) => {
    const i = parseFloat(initial) || 1; // avoid division by zero
    const c = parseFloat(current) || 0;
    const percent = Math.min(100, Math.max(0, Math.round((c / i) * 100)));
    
    let color = 'bg-violet-600';
    let textColor = 'text-fuchsia-400';

    if (percent < 30) {
        color = 'bg-emerald-500';
        textColor = 'text-emerald-400';
    } else if (percent > 70) {
        color = 'bg-pink-600';
        textColor = 'text-pink-400';
    }

    return { percent, color, textColor };
  };

  const IconComponent = ({ name, className }: { name: string, className?: string }) => {
    const Icon = ICON_MAP[name] || Wallet;
    return <Icon className={className} />;
  };

  return (
    <div className="flex flex-col h-full bg-black relative">
      
      {/* HEADER */}
      <div className="px-4 py-4 flex items-center justify-between bg-black/80 backdrop-blur-md sticky top-0 z-30 border-b border-white/5">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-gray-300 hover:text-white">
            <ChevronLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-lg">Agregar Deudas</h2>
        <button 
            onClick={handleAddNew}
            className="w-10 h-10 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 flex items-center justify-center text-white shadow-lg shadow-purple-900/40 active:scale-95 transition-transform">
            <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* CONTENT LIST */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-32 no-scrollbar">
        {debts.map((item) => {
            const stats = getDebtStats(item.initial, item.current);
            return (
                <div 
                    key={item.id} 
                    onClick={() => handleEdit(item)}
                    className="bg-surface border border-white/5 rounded-3xl p-5 animate-fade-in-up cursor-pointer hover:border-white/20 transition-colors active:scale-[0.98]"
                >
                    {/* Card Header */}
                    <div className="flex items-start justify-between mb-4">
                        <div className="flex gap-4">
                            <div className="w-12 h-12 rounded-2xl bg-slate-800/50 flex items-center justify-center border border-white/5">
                                <IconComponent name={item.icon} className="w-6 h-6 text-fuchsia-400" />
                            </div>
                            <div>
                                <h3 className="font-bold text-lg leading-tight">{item.name || 'Sin Nombre'}</h3>
                                <p className="text-xs text-gray-500 mt-1">{item.subtitle || 'Sin detalles'}</p>
                            </div>
                        </div>
                        <span className={`font-bold ${stats.textColor}`}>{stats.percent}%</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden mb-6">
                        <div 
                            className={`h-full ${stats.color} shadow-[0_0_10px_currentColor] transition-all duration-1000`} 
                            style={{ width: `${stats.percent}%` }}
                        ></div>
                    </div>

                    {/* Details Grid */}
                    <div className="grid grid-cols-3 gap-2 text-center pointer-events-none">
                        <div>
                            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Monto Inicial</p>
                            <p className="font-bold text-sm text-white">{formatCurrency(item.initial)}</p>
                        </div>
                        <div className="border-x border-white/5">
                            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Saldo Actual</p>
                            <p className={`font-bold text-sm ${stats.textColor}`}>{formatCurrency(item.current)}</p>
                        </div>
                        <div>
                            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Pago Objetivo</p>
                            <p className="font-bold text-sm text-white">{formatCurrency(item.minPay)}</p>
                        </div>
                    </div>
                </div>
            );
        })}
        
        {debts.length === 0 && (
            <div className="text-center py-10 text-gray-500">
                <p>No tienes deudas registradas.</p>
                <p className="text-xs mt-2">Toca el botón + para agregar una.</p>
            </div>
        )}
      </div>

      {/* FOOTER */}
      <div className="p-4 pt-2 pb-6 bg-gradient-to-t from-black via-black to-transparent sticky bottom-0 z-30">
        <p className="text-[10px] text-center text-gray-400 mb-4 font-semibold uppercase tracking-wide max-w-[250px] mx-auto leading-relaxed">
            Pasar a métodos de pago y seguir personalizando tu experiencia
        </p>
        <Button onClick={onFinish}>
            SIGUIENTE
        </Button>
      </div>

      {/* EDIT MODAL */}
      {editingDebt && (
        <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
             <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl relative overflow-hidden animate-slide-up max-h-[90vh] overflow-y-auto no-scrollbar">
                
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold">
                        {debts.find(d => d.id === editingDebt.id) ? 'Editar Deuda' : 'Nueva Deuda'}
                    </h3>
                    <button onClick={() => setEditingDebt(null)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <div className="space-y-4">
                    {/* Name */}
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Nombre de la Deuda</label>
                        <input 
                            type="text" 
                            placeholder="Ej. Tarjeta Oro"
                            value={editingDebt.name}
                            onChange={(e) => setEditingDebt({...editingDebt, name: e.target.value})}
                            className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500 transition-colors"
                        />
                    </div>

                    {/* Subtitle */}
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Detalle / Fecha Corte</label>
                        <input 
                            type="text" 
                            placeholder="Ej. Corte el 15 de cada mes"
                            value={editingDebt.subtitle}
                            onChange={(e) => setEditingDebt({...editingDebt, subtitle: e.target.value})}
                            className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-purple-500 transition-colors"
                        />
                    </div>

                    {/* Financials Grid */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Monto Inicial</label>
                            <div className="relative">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                                <input 
                                    type="number" 
                                    value={editingDebt.initial}
                                    onChange={(e) => setEditingDebt({...editingDebt, initial: e.target.value})}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 pl-8 text-white focus:outline-none focus:border-purple-500 transition-colors"
                                />
                            </div>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2 block">Saldo Actual</label>
                            <div className="relative">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                                <input 
                                    type="number" 
                                    value={editingDebt.current}
                                    onChange={(e) => setEditingDebt({...editingDebt, current: e.target.value})}
                                    className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 pl-8 text-white focus:outline-none focus:border-purple-500 transition-colors"
                                />
                            </div>
                        </div>
                    </div>

                     <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1 block">Pago Mensual Objetivo</label>
                        <p className="text-[10px] text-gray-400 mb-3 leading-tight">
                            Cantidad que te gustaría abonar mensualmente para esta deuda.
                        </p>
                        <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                            <input 
                                type="number" 
                                value={editingDebt.minPay}
                                onChange={(e) => setEditingDebt({...editingDebt, minPay: e.target.value})}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 pl-8 text-white focus:outline-none focus:border-purple-500 transition-colors"
                            />
                        </div>
                    </div>

                    {/* Icon Picker */}
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 block">Icono</label>
                        <div className="grid grid-cols-5 gap-2">
                            {Object.keys(ICON_MAP).map((iconKey) => (
                                <button 
                                    key={iconKey}
                                    onClick={() => setEditingDebt({...editingDebt, icon: iconKey})}
                                    className={`aspect-square rounded-xl flex items-center justify-center transition-all ${
                                        editingDebt.icon === iconKey 
                                        ? 'bg-purple-600 text-white shadow-lg scale-110' 
                                        : 'bg-slate-800 text-gray-400 hover:bg-slate-700'
                                    }`}
                                >
                                    <IconComponent name={iconKey} className="w-5 h-5" />
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="pt-4 flex flex-col gap-3">
                        <Button onClick={handleSave}>
                            Guardar Cambios
                        </Button>
                        {debts.find(d => d.id === editingDebt.id) && (
                             <button 
                                onClick={deleteDebt}
                                className="w-full py-3 text-red-400 font-bold text-sm hover:bg-red-500/10 rounded-xl transition-colors">
                                Eliminar Deuda
                            </button>
                        )}
                    </div>
                </div>
             </div>
        </div>
      )}

      {/* INTRO MODAL */}
      {showIntroModal && (
        <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
            <div className="bg-surface border border-white/10 rounded-[2rem] p-8 w-full max-w-sm shadow-2xl relative overflow-hidden flex flex-col items-center">
                {/* Modal Glow */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-purple-500"></div>
                <div className="absolute -top-20 -right-20 w-60 h-60 bg-purple-600/10 blur-[60px] rounded-full pointer-events-none"></div>

                <div className="flex justify-center mb-6 mt-2 relative">
                    <div className="absolute inset-0 bg-fuchsia-500/20 blur-xl rounded-full"></div>
                    <div className="w-20 h-20 rounded-full bg-slate-900 border border-white/10 flex items-center justify-center shadow-lg relative z-10">
                        <Wallet className="w-10 h-10 text-fuchsia-400" />
                    </div>
                </div>

                <h3 className="text-2xl font-bold text-center mb-4">Controla tus Deudas</h3>
                
                <p className="text-center text-gray-300 text-sm mb-8 leading-relaxed">
                    Registra aquí tus préstamos o tarjetas pendientes. Esto nos ayudará a calcular cuánto de tu presupuesto semanal debe destinarse a recuperar tu libertad financiera.
                </p>

                <Button onClick={() => setShowIntroModal(false)}>
                    Entendido
                </Button>
            </div>
        </div>
      )}
    </div>
  );
};