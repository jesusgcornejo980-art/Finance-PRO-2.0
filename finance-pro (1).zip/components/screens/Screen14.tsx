import React, { useState } from 'react';
import { User, Wallet, BarChart3, Plus, CreditCard, Home, Languages, Coins, Shapes, FileText, Download, ChevronRight, Settings, Check, X, FileSpreadsheet, File as FileIcon, Calendar, CheckSquare, Square, LogOut } from 'lucide-react';
import { Button } from '../Button';
import { Language, Currency } from '../../types';

interface Props {
  onBackToBudget: () => void;
  onGoToAnalysis: () => void;
  onGoToCards: () => void;
  onAddTransaction: () => void;
  onNavigateToCategories: () => void;
  onNavigateToDebts: () => void;
  onNavigateToMethods: () => void;
  onExport: (format: 'excel' | 'pdf', period: 'all' | 'current_month' | 'last_month', dataConfig: any) => void;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  currentCurrency: Currency;
  onCurrencyChange: (curr: Currency) => void;
  texts: any;
  onResetApp?: () => void;
}

export const Screen14: React.FC<Props> = ({ 
    onBackToBudget, 
    onGoToAnalysis, 
    onGoToCards, 
    onAddTransaction,
    onNavigateToCategories,
    onNavigateToDebts,
    onNavigateToMethods,
    onExport,
    currentLanguage,
    onLanguageChange,
    currentCurrency,
    onCurrencyChange,
    texts,
    onResetApp
}) => {
  const [currency, setCurrency] = useState('USD');
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);
  
  // Export Modal State
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [exportStep, setExportStep] = useState<'format' | 'config'>('format');
  const [selectedFormat, setSelectedFormat] = useState<'excel' | 'pdf' | null>(null);
  
  // Export Config State
  const [exportPeriod, setExportPeriod] = useState<'all' | 'current_month' | 'last_month'>('current_month');
  const [dataToExport, setDataToExport] = useState({
      transactions: true,
      budgets: true,
      debts: true
  });

  const toggleCurrency = () => setCurrency(prev => prev === 'USD' ? 'EUR' : 'USD');

  const handleExportClick = () => {
      setExportStep('format');
      setSelectedFormat(null);
      setIsExportModalOpen(true);
  };

  const handleFormatSelect = (format: 'excel' | 'pdf') => {
      setSelectedFormat(format);
      setExportStep('config');
  };

  const handleFinalExport = () => {
      if (selectedFormat) {
          onExport(selectedFormat, exportPeriod, dataToExport);
          setIsExportModalOpen(false);
      }
  };

  const toggleDataExport = (key: keyof typeof dataToExport) => {
      setDataToExport(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const languages = [
      { code: 'es', name: 'Español', flag: 'https://flagcdn.com/w40/mx.png' },
      { code: 'en', name: 'English', flag: 'https://flagcdn.com/w40/us.png' },
      { code: 'pt', name: 'Português', flag: 'https://flagcdn.com/w40/br.png' },
  ];

  const currencies = [
      { code: 'USD', name: 'US Dollar', symbol: '$', flag: 'https://flagcdn.com/w40/us.png' },
      { code: 'EUR', name: 'Euro', symbol: '€', flag: 'https://flagcdn.com/w40/eu.png' },
      { code: 'MXN', name: 'Peso Mexicano', symbol: '$', flag: 'https://flagcdn.com/w40/mx.png' },
      { code: 'COP', name: 'Peso Colombiano', symbol: '$', flag: 'https://flagcdn.com/w40/co.png' },
      { code: 'ARS', name: 'Peso Argentino', symbol: '$', flag: 'https://flagcdn.com/w40/ar.png' },
      { code: 'CLP', name: 'Peso Chileno', symbol: '$', flag: 'https://flagcdn.com/w40/cl.png' },
      { code: 'BRL', name: 'Real Brasileiro', symbol: 'R$', flag: 'https://flagcdn.com/w40/br.png' },
      { code: 'GBP', name: 'British Pound', symbol: '£', flag: 'https://flagcdn.com/w40/gb.png' },
  ];

  const currentLangName = languages.find(l => l.code === currentLanguage)?.name;
  const currentCurrencyData = currencies.find(c => c.code === currentCurrency);

  return (
    <div className="flex flex-col h-full bg-black relative">
        
        {/* --- HEADER --- */}
        <div className="px-6 pt-10 pb-4 flex justify-between items-center z-10 sticky top-0 bg-black/90 backdrop-blur-md">
            <h1 className="text-2xl font-bold text-white">{texts.profile.title}</h1>
            <button className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                 <Settings className="w-5 h-5" />
            </button>
        </div>

        {/* --- CONTENT --- */}
        <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
            
            {/* 1. USER PROFILE CARD */}
            <div className="px-6 mb-8 mt-2">
                <div className="bg-gradient-to-br from-[#1e1b4b] to-[#312e81] border border-white/10 rounded-3xl p-6 flex items-center gap-5 relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-fuchsia-600/20 blur-[50px] rounded-full pointer-events-none"></div>
                    
                    <div className="w-20 h-20 rounded-full border-2 border-white/20 p-1 relative z-10">
                        <div className="w-full h-full rounded-full bg-gray-800 overflow-hidden">
                            <img 
                                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80" 
                                alt="User" 
                                className="w-full h-full object-cover"
                            />
                        </div>
                        <div className="absolute bottom-0 right-0 w-5 h-5 bg-emerald-500 border-2 border-[#312e81] rounded-full"></div>
                    </div>
                    
                    <div className="relative z-10">
                        <h2 className="text-xl font-bold text-white">Usuario Pro</h2>
                        <p className="text-xs text-indigo-300 mb-2">{texts.profile.memberSince} 2023</p>
                        <span className="px-2 py-1 rounded-md bg-white/10 text-[10px] font-bold text-white border border-white/10">PREMIUM</span>
                    </div>
                </div>
            </div>

            {/* 2. GENERAL SETTINGS */}
            <div className="px-6 mb-2">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-2">{texts.profile.generalSettings}</h3>
                <div className="space-y-3">
                    {/* Language */}
                    <div className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:bg-white/5 transition-colors cursor-pointer" onClick={() => setIsLanguageModalOpen(true)}>
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400">
                                <Languages className="w-5 h-5" />
                            </div>
                            <span className="text-sm font-bold text-white">{texts.profile.language}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-500 font-medium">{currentLangName}</span>
                            <ChevronRight className="w-4 h-4 text-gray-600" />
                        </div>
                    </div>

                    {/* Currency */}
                    <div className="bg-[#12121a] border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:bg-white/5 transition-colors cursor-pointer" onClick={() => setIsCurrencyModalOpen(true)}>
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                                <Coins className="w-5 h-5" />
                            </div>
                            <span className="text-sm font-bold text-white">{texts.profile.currency}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-500 font-medium">{currentCurrencyData?.code} ({currentCurrencyData?.symbol})</span>
                            <ChevronRight className="w-4 h-4 text-gray-600" />
                        </div>
                    </div>
                </div>
            </div>

            {/* 3. DATA CONFIGURATION */}
            <div className="px-6 mt-6 mb-2">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-2">{texts.profile.myData}</h3>
                <div className="space-y-3">
                    
                    {/* Categories */}
                    <button onClick={onNavigateToCategories} className="w-full bg-[#12121a] border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:bg-white/5 transition-colors group">
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 group-hover:bg-purple-500/20 transition-colors">
                                <Shapes className="w-5 h-5" />
                            </div>
                            <span className="text-sm font-bold text-white">{texts.profile.categories}</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-600" />
                    </button>

                    {/* Payment Methods */}
                    <button onClick={onNavigateToMethods} className="w-full bg-[#12121a] border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:bg-white/5 transition-colors group">
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-fuchsia-500/10 flex items-center justify-center text-fuchsia-400 group-hover:bg-fuchsia-500/20 transition-colors">
                                <CreditCard className="w-5 h-5" />
                            </div>
                            <span className="text-sm font-bold text-white">{texts.profile.paymentMethods}</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-600" />
                    </button>

                    {/* Debts */}
                    <button onClick={onNavigateToDebts} className="w-full bg-[#12121a] border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:bg-white/5 transition-colors group">
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-pink-500/10 flex items-center justify-center text-pink-400 group-hover:bg-pink-500/20 transition-colors">
                                <FileText className="w-5 h-5" />
                            </div>
                            <span className="text-sm font-bold text-white">{texts.profile.debts}</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-600" />
                    </button>

                </div>
            </div>

            {/* 4. SYSTEM */}
            <div className="px-6 mt-6">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 px-2">{texts.profile.system}</h3>
                
                <div className="space-y-3">
                    <button 
                        onClick={handleExportClick}
                        className="w-full bg-slate-900/50 border border-white/5 rounded-2xl p-4 flex items-center justify-center gap-3 hover:bg-white/5 transition-colors group"
                    >
                        <Download className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                        <span className="text-sm font-bold text-gray-300 group-hover:text-white transition-colors">{texts.profile.export}</span>
                    </button>

                    {onResetApp && (
                        <button 
                            onClick={onResetApp}
                            className="w-full bg-red-950/20 border border-red-900/30 rounded-2xl p-4 flex items-center justify-center gap-3 hover:bg-red-900/30 transition-colors group"
                        >
                            <LogOut className="w-5 h-5 text-red-400 group-hover:text-red-300 transition-colors" />
                            <span className="text-sm font-bold text-red-400 group-hover:text-red-300 transition-colors">Reiniciar App (Demo)</span>
                        </button>
                    )}
                </div>
                
                <p className="text-center text-[10px] text-gray-600 mt-6">
                    Version 1.0.3 (Build 2024)
                </p>
            </div>

        </div>

        {/* --- BOTTOM NAVIGATION BAR --- */}
        <div className="absolute bottom-0 left-0 w-full h-24 bg-black/90 backdrop-blur-xl border-t border-white/5 flex items-start justify-between px-6 pt-4 z-50">
          
          <button onClick={onBackToBudget} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors">
             <Home className="w-6 h-6" />
             <span className="text-[10px] font-medium">{texts.dashboard.navBudget}</span>
          </button>

          <button onClick={onGoToAnalysis} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <BarChart3 className="w-6 h-6" />
             <span className="text-[10px] font-medium">{texts.dashboard.navAnalysis}</span>
          </button>

          {/* Floating Action Button */}
          <button 
            onClick={onAddTransaction}
            className="w-16 h-16 -mt-8 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center shadow-[0_0_20px_rgba(192,38,211,0.4)] border-4 border-black active:scale-95 transition-transform"
          >
             <Plus className="w-8 h-8 text-white stroke-[3]" />
          </button>

          <button onClick={onGoToCards} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <CreditCard className="w-6 h-6" />
             <span className="text-[10px] font-medium">{texts.dashboard.navAccounts}</span>
          </button>

          {/* Active Profile Button */}
          <button className="flex flex-col items-center gap-1 text-fuchsia-500 mt-1 cursor-default">
             <div className="p-1 rounded-xl bg-fuchsia-500/10">
                <User className="w-6 h-6" />
             </div>
             <span className="text-[10px] font-bold">{texts.dashboard.navProfile}</span>
          </button>

        </div>

        {/* --- LANGUAGE MODAL --- */}
        {isLanguageModalOpen && (
            <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
                <div className="bg-surface border border-white/10 rounded-[2rem] p-6 w-full max-w-sm shadow-2xl animate-slide-up">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-white">{texts.profile.language}</h3>
                        <button onClick={() => setIsLanguageModalOpen(false)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="space-y-3">
                        {languages.map((lang) => (
                            <button
                                key={lang.code}
                                onClick={() => {
                                    onLanguageChange(lang.code as any);
                                    setIsLanguageModalOpen(false);
                                }}
                                className={`w-full p-4 rounded-xl border flex items-center justify-between transition-all ${
                                    currentLanguage === lang.code 
                                    ? 'bg-purple-500/20 border-purple-500/50' 
                                    : 'bg-slate-900 border-white/5 hover:bg-white/5'
                                }`}
                            >
                                <div className="flex items-center gap-4">
                                    <img src={lang.flag} alt={lang.name} className="w-8 h-6 rounded object-cover" />
                                    <span className={`text-base font-bold ${currentLanguage === lang.code ? 'text-white' : 'text-gray-300'}`}>
                                        {lang.name}
                                    </span>
                                </div>
                                {currentLanguage === lang.code && (
                                    <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center">
                                        <Check className="w-4 h-4 text-white" />
                                    </div>
                                )}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        )}

        {/* --- CURRENCY MODAL --- */}
        {isCurrencyModalOpen && (
            <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
                <div className="bg-surface border border-white/10 rounded-[2rem] p-6 w-full max-w-sm shadow-2xl animate-slide-up max-h-[80vh] overflow-y-auto no-scrollbar">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-white">{texts.profile.currency}</h3>
                        <button onClick={() => setIsCurrencyModalOpen(false)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="space-y-3">
                        {currencies.map((curr) => (
                            <button
                                key={curr.code}
                                onClick={() => {
                                    onCurrencyChange(curr.code as any);
                                    setIsCurrencyModalOpen(false);
                                }}
                                className={`w-full p-4 rounded-xl border flex items-center justify-between transition-all ${
                                    currentCurrency === curr.code 
                                    ? 'bg-emerald-500/20 border-emerald-500/50' 
                                    : 'bg-slate-900 border-white/5 hover:bg-white/5'
                                }`}
                            >
                                <div className="flex items-center gap-4">
                                    <div className="relative">
                                         <img src={curr.flag} alt={curr.name} className="w-8 h-6 rounded object-cover" />
                                         <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-black border border-white/10 flex items-center justify-center text-[8px] font-bold text-white">
                                             {curr.symbol}
                                         </div>
                                    </div>
                                    <div className="text-left">
                                         <span className={`text-sm font-bold block ${currentCurrency === curr.code ? 'text-white' : 'text-gray-300'}`}>
                                            {curr.code}
                                        </span>
                                        <span className="text-[10px] text-gray-500">{curr.name}</span>
                                    </div>
                                </div>
                                {currentCurrency === curr.code && (
                                    <div className="w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center">
                                        <Check className="w-4 h-4 text-white" />
                                    </div>
                                )}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        )}

        {/* --- EXPORT MODAL --- */}
        {isExportModalOpen && (
            <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
                <div className="bg-surface border-t sm:border border-white/10 rounded-t-[2.5rem] sm:rounded-[2rem] p-6 w-full max-w-sm shadow-2xl animate-slide-up relative overflow-hidden">
                    
                    {/* Background decor */}
                    <div className="absolute top-0 right-0 w-40 h-40 bg-purple-600/10 blur-[60px] rounded-full pointer-events-none"></div>

                    <div className="flex justify-between items-center mb-6 relative z-10">
                        <div className="flex items-center gap-3">
                            {exportStep === 'config' && (
                                <button onClick={() => setExportStep('format')} className="p-1 -ml-2 text-gray-400 hover:text-white">
                                    <ChevronRight className="w-5 h-5 rotate-180" />
                                </button>
                            )}
                            <h3 className="text-xl font-bold text-white">
                                {exportStep === 'format' ? texts.export.selectFormat : texts.export.configTitle}
                            </h3>
                        </div>
                        <button onClick={() => setIsExportModalOpen(false)} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    {/* STEP 1: FORMAT SELECTION */}
                    {exportStep === 'format' && (
                        <div className="space-y-4">
                            <button 
                                onClick={() => handleFormatSelect('excel')}
                                className="w-full p-5 rounded-2xl bg-[#12121a] border border-white/5 hover:bg-emerald-900/20 hover:border-emerald-500/50 transition-all flex items-center gap-4 group"
                            >
                                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                                    <FileSpreadsheet className="w-6 h-6 text-emerald-500" />
                                </div>
                                <div className="text-left flex-1">
                                    <span className="block text-white font-bold text-base">Excel / CSV</span>
                                    <span className="text-xs text-gray-500">{texts.export.excelDesc}</span>
                                </div>
                                <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-emerald-500" />
                            </button>

                            <button 
                                onClick={() => handleFormatSelect('pdf')}
                                className="w-full p-5 rounded-2xl bg-[#12121a] border border-white/5 hover:bg-red-900/20 hover:border-red-500/50 transition-all flex items-center gap-4 group"
                            >
                                <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                                    <FileIcon className="w-6 h-6 text-red-500" />
                                </div>
                                <div className="text-left flex-1">
                                    <span className="block text-white font-bold text-base">PDF Document</span>
                                    <span className="text-xs text-gray-500">{texts.export.pdfDesc}</span>
                                </div>
                                <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-red-500" />
                            </button>
                        </div>
                    )}

                    {/* STEP 2: CONFIGURATION */}
                    {exportStep === 'config' && (
                        <div className="space-y-6">
                            
                            {/* Period Selection */}
                            <div>
                                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                                    <Calendar className="w-3 h-3" /> {texts.export.period}
                                </label>
                                <div className="grid grid-cols-3 gap-2">
                                    {['current_month', 'last_month', 'all'].map((p) => (
                                        <button
                                            key={p}
                                            onClick={() => setExportPeriod(p as any)}
                                            className={`py-3 px-2 rounded-xl text-[10px] font-bold border transition-all ${
                                                exportPeriod === p 
                                                ? 'bg-purple-600 border-purple-500 text-white shadow-lg' 
                                                : 'bg-slate-900 border-white/10 text-gray-400 hover:bg-white/5'
                                            }`}
                                        >
                                            {p === 'all' ? texts.export.allTime : p === 'current_month' ? texts.export.thisMonth : texts.export.lastMonth}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Data Selection */}
                            <div>
                                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                                    <CheckSquare className="w-3 h-3" /> {texts.export.dataToInclude}
                                </label>
                                <div className="space-y-2">
                                    {[
                                        { id: 'transactions', label: texts.export.transactions },
                                        { id: 'budgets', label: texts.export.budgets },
                                        { id: 'debts', label: texts.export.debts }
                                    ].map((item) => (
                                        <div 
                                            key={item.id}
                                            onClick={() => toggleDataExport(item.id as any)}
                                            className="flex items-center justify-between p-3 rounded-xl bg-[#12121a] border border-white/5 cursor-pointer hover:bg-white/5 transition-colors"
                                        >
                                            <span className="text-sm font-medium text-gray-300">{item.label}</span>
                                            {dataToExport[item.id as keyof typeof dataToExport] ? (
                                                <div className="w-5 h-5 rounded-md bg-purple-500 flex items-center justify-center">
                                                    <Check className="w-3 h-3 text-white" />
                                                </div>
                                            ) : (
                                                <div className="w-5 h-5 rounded-md border-2 border-gray-600"></div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <Button onClick={handleFinalExport} showIcon>
                                {texts.common.download.toUpperCase()} {selectedFormat?.toUpperCase()}
                            </Button>
                        </div>
                    )}

                </div>
            </div>
        )}

    </div>
  );
};