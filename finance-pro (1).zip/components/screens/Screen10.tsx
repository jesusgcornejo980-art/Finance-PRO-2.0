import React, { useState, useMemo } from 'react';
import { X, ChevronDown, Banknote, CreditCard, Wallet, AlertTriangle, CheckCircle2, ArrowUpCircle, ArrowDownCircle, Info, Landmark, AlignLeft, AlertOctagon } from 'lucide-react';
import { Button } from '../Button';
import { Section, DebtItem, PaymentMethod, Currency } from '../../types';

interface Props {
  sections: Section[];
  debts: DebtItem[];
  methods: PaymentMethod[];
  weeklyBalance: number;
  spentAmounts: { needs: number; savings: number; wants: number };
  onClose: () => void;
  onSave: (data: { amount: string; type: 'expense' | 'income'; isWeekStart: boolean; categoryId?: string; methodId?: string; debtId?: string; description?: string }) => void;
  showIntro?: boolean;
  onIntroClosed?: () => void;
  texts: any;
  currency: Currency;
}

export const Screen10: React.FC<Props> = ({ 
    sections, 
    debts, 
    methods,
    weeklyBalance, 
    spentAmounts, 
    onClose, 
    onSave,
    showIntro = false,
    onIntroClosed,
    texts,
    currency
}) => {
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'expense' | 'income'>('expense');
  
  // State for selections
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedMethod, setSelectedMethod] = useState<string | null>(methods.length > 0 ? methods[0].id.toString() : null);
  const [selectedDebt, setSelectedDebt] = useState<string | null>(null);
  
  // Toggles
  const [isWeekStart, setIsWeekStart] = useState(false);
  const [isDebtPayment, setIsDebtPayment] = useState(false); // New Toggle for Debt
  
  const [internalShowIntro, setInternalShowIntro] = useState(showIntro);

  // Warning Modals State
  const [warningStep, setWarningStep] = useState<0 | 1 | 2>(0); // 0 = None, 1 = First Warning, 2 = Second Warning
  const [pendingSaveData, setPendingSaveData] = useState<any>(null);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmount(e.target.value);
  };

  const executeSave = (data: any) => {
      onSave(data);
      setWarningStep(0);
      setPendingSaveData(null);
  };

  const handleSave = () => {
    if (!amount || parseFloat(amount) === 0) return;
    if (!selectedMethod) return;

    const value = parseFloat(amount);

    // Validation logic
    if (type === 'expense') {
        if (isDebtPayment && !selectedDebt) return;
        if (!isDebtPayment && !selectedCategory) return;
    }

    const saveData = {
        amount,
        type,
        isWeekStart: type === 'income' ? isWeekStart : false,
        categoryId: (type === 'expense' && !isDebtPayment) ? (selectedCategory || undefined) : undefined,
        methodId: selectedMethod,
        debtId: (type === 'expense' && isDebtPayment) ? (selectedDebt || undefined) : undefined,
        description: (description && ((type === 'expense' && !isDebtPayment) || type === 'income')) ? description : undefined
    };

    // --- BUDGET OVERFLOW CHECK LOGIC ---
    if (type === 'expense' && !isDebtPayment && selectedCategory) {
        // 1. Calculate Total Basis (Total Income for the week)
        const totalBasis = weeklyBalance + spentAmounts.needs + spentAmounts.savings + spentAmounts.wants;
        
        // 2. Determine Section ID from Category ID
        const sectionId = sections.find(s => s.items.some(i => i.id === selectedCategory))?.id;
        
        if (sectionId && (sectionId === 'needs' || sectionId === 'wants' || sectionId === 'savings')) {
            let budgetLimit = 0;
            let currentSpent = 0;

            if (sectionId === 'needs') {
                budgetLimit = totalBasis * 0.50;
                currentSpent = spentAmounts.needs;
            } else if (sectionId === 'wants') {
                budgetLimit = totalBasis * 0.20;
                currentSpent = spentAmounts.wants;
            } else if (sectionId === 'savings') {
                budgetLimit = totalBasis * 0.30;
                currentSpent = spentAmounts.savings;
            }

            // 3. Check Condition
            if ((currentSpent + value) > budgetLimit) {
                // EXCEEDS BUDGET -> Trigger Warning Flow
                setPendingSaveData(saveData);
                setWarningStep(1);
                return;
            }
        }
    }

    // If no warning needed, save directly
    executeSave(saveData);
  };

  const formatCurrency = (val: number | string) => {
      const num = typeof val === 'string' ? parseFloat(val) : val;
      if (isNaN(num)) return '$0';
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: currency, maximumFractionDigits: 0 }).format(num);
  };

  // Calculate Total Liquid Assets (Cash + Debit)
  const totalAccountsBalance = useMemo(() => {
      return methods.reduce((acc, curr) => {
          if (curr.type !== 'credit') {
              return acc + (parseFloat(curr.balance) || 0);
          }
          return acc;
      }, 0);
  }, [methods]);

  // Helper to find icon component (simplified for this screen)
  const getCategoryIcon = (sectionId: string) => {
      switch(sectionId) {
          case 'needs': return <div className="w-2 h-2 rounded-full bg-purple-500"></div>;
          case 'wants': return <div className="w-2 h-2 rounded-full bg-violet-500"></div>;
          case 'savings': return <div className="w-2 h-2 rounded-full bg-fuchsia-500"></div>;
          default: return <div className="w-2 h-2 rounded-full bg-gray-500"></div>;
      }
  };
  
  // Get symbol from format
  const getCurrencySymbol = () => {
      return (0).toLocaleString('en-US', { style: 'currency', currency: currency, minimumFractionDigits: 0 }).replace(/\d/g, '').trim();
  }

  return (
    <div className="flex flex-col h-full bg-black relative">
        
        {/* --- HEADER --- */}
        <div className="px-4 py-4 flex items-center justify-between z-10 shrink-0">
            {/* Show Skip button if it's the intro flow */}
            {showIntro ? (
                <button onClick={onClose} className="px-4 py-2 rounded-full bg-surface border border-white/5 text-gray-400 text-xs font-bold hover:text-white">
                    Omitir
                </button>
            ) : (
                <button onClick={onClose} className="w-10 h-10 rounded-full bg-surface border border-white/5 flex items-center justify-center text-gray-400 hover:text-white">
                    <X className="w-5 h-5" />
                </button>
            )}

            <div className="flex bg-surface rounded-full p-1 border border-white/5">
                <button 
                    onClick={() => { setType('expense'); setIsDebtPayment(false); }}
                    className={`px-4 py-2 rounded-full text-xs font-bold transition-all flex items-center gap-2 ${type === 'expense' ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-400'}`}
                >
                    <ArrowUpCircle className="w-3 h-3" /> {texts.transaction.expense.toUpperCase()}
                </button>
                <button 
                    onClick={() => { setType('income'); setIsDebtPayment(false); }}
                    className={`px-4 py-2 rounded-full text-xs font-bold transition-all flex items-center gap-2 ${type === 'income' ? 'bg-emerald-600 text-white shadow-lg' : 'text-gray-400'}`}
                >
                    <ArrowDownCircle className="w-3 h-3" /> {texts.transaction.income.toUpperCase()}
                </button>
            </div>
            
            {/* Spacer or Close button for symmetry/logic */}
            <div className="w-10"></div>
        </div>

        {/* --- CONTEXT BAR --- */}
        <div className="px-6 flex justify-center gap-4 mb-2 shrink-0">
            <div className="flex flex-col items-center">
                <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">{texts.dashboard.availableBalance}</span>
                <span className="text-sm font-bold text-white">{formatCurrency(weeklyBalance)}</span>
            </div>
            <div className="w-[1px] bg-white/10 h-8"></div>
            <div className="flex flex-col items-center">
                <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">Total</span>
                <span className="text-sm font-bold text-gray-300">{formatCurrency(totalAccountsBalance)}</span>
            </div>
        </div>

        {/* --- AMOUNT INPUT (NATIVE) --- */}
        <div className="flex flex-col items-center justify-center py-6 shrink-0">
            <span className="text-gray-500 text-sm font-bold uppercase tracking-widest mb-2">
                {type === 'expense' ? (isDebtPayment ? texts.transaction.expense : texts.transaction.amountToDiscount) : texts.transaction.amountToDeposit}
            </span>
            <div className="relative flex items-center justify-center w-full px-10">
                <span className={`text-6xl font-bold ${type === 'expense' ? 'text-white' : 'text-emerald-400'} mr-2`}>{getCurrencySymbol()}</span>
                <input
                    type="number"
                    inputMode="decimal"
                    value={amount}
                    onChange={handleAmountChange}
                    placeholder="0"
                    className={`bg-transparent text-6xl font-bold tracking-tighter w-full max-w-[250px] text-center focus:outline-none placeholder-gray-700 ${type === 'expense' ? 'text-white' : 'text-emerald-400'}`}
                />
            </div>
        </div>

        {/* --- FORM SECTION --- */}
        <div className="bg-surface rounded-t-[2.5rem] border-t border-white/10 flex-1 flex flex-col overflow-hidden shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
            
            <div className="flex-1 overflow-y-auto p-6 space-y-6 pb-32">
                
                {/* 1. PAYMENT METHOD SELECTOR */}
                <div>
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 block">
                        {type === 'expense' ? texts.transaction.payWith : texts.transaction.depositIn}
                    </label>
                    <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
                        {methods.map(method => (
                            <button
                                key={method.id}
                                onClick={() => setSelectedMethod(method.id.toString())}
                                className={`flex items-center gap-3 px-4 py-3 rounded-2xl border transition-all min-w-[140px] ${
                                    selectedMethod === method.id.toString()
                                    ? 'bg-purple-600/20 border-purple-500 text-white'
                                    : 'bg-black/20 border-white/5 text-gray-400 hover:bg-white/5'
                                }`}
                            >
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${method.type === 'cash' ? 'bg-emerald-500/20' : 'bg-indigo-500/20'}`}>
                                    {method.type === 'cash' ? <Banknote className="w-4 h-4" /> : <CreditCard className="w-4 h-4" />}
                                </div>
                                <div className="text-left">
                                    <div className="text-xs font-bold">{method.name}</div>
                                    <div className="text-[9px] opacity-70">${method.balance}</div>
                                </div>
                                {selectedMethod === method.id.toString() && <div className="w-2 h-2 rounded-full bg-purple-500 ml-auto"></div>}
                            </button>
                        ))}
                    </div>
                </div>
                
                {/* 2. DEBT TOGGLE (Only for Expense) */}
                {type === 'expense' && (
                     <div className={`border rounded-2xl p-4 flex items-center justify-between animate-fade-in-up transition-colors cursor-pointer ${isDebtPayment ? 'bg-indigo-500/10 border-indigo-500/20' : 'bg-black/20 border-white/5'}`} onClick={() => setIsDebtPayment(!isDebtPayment)}>
                        <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isDebtPayment ? 'bg-indigo-500/20' : 'bg-gray-800'}`}>
                                <Landmark className={`w-5 h-5 ${isDebtPayment ? 'text-indigo-400' : 'text-gray-500'}`} />
                            </div>
                            <div>
                                <p className={`text-sm font-bold ${isDebtPayment ? 'text-indigo-100' : 'text-gray-300'}`}>{texts.transaction.isDebtPayment}</p>
                                <p className={`text-[10px] ${isDebtPayment ? 'text-indigo-200/70' : 'text-gray-500'}`}>
                                    {isDebtPayment ? texts.transaction.debtDesc : texts.transaction.expense}
                                </p>
                            </div>
                        </div>
                        <button 
                            className={`w-12 h-6 rounded-full p-1 transition-colors ${isDebtPayment ? 'bg-indigo-500' : 'bg-gray-700'}`}
                        >
                            <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${isDebtPayment ? 'translate-x-6' : 'translate-x-0'}`}></div>
                        </button>
                    </div>
                )}

                {/* 3. CATEGORY OR DEBT SELECTOR (Only for Expenses) */}
                {type === 'expense' && (
                    <div className="animate-fade-in-up">
                         {isDebtPayment ? (
                             // --- DEBT SELECTOR ---
                             <>
                                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 block">{texts.transaction.selectDebt}</label>
                                {debts.length > 0 ? (
                                    <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
                                        {debts.map(debt => (
                                            <button
                                                key={debt.id}
                                                onClick={() => setSelectedDebt(debt.id.toString())}
                                                className={`flex items-center gap-3 px-4 py-3 rounded-2xl border transition-all min-w-[140px] ${
                                                    selectedDebt === debt.id.toString()
                                                    ? 'bg-indigo-600/20 border-indigo-500 text-white'
                                                    : 'bg-black/20 border-white/5 text-gray-400 hover:bg-white/5'
                                                }`}
                                            >
                                                <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center">
                                                    <CreditCard className="w-4 h-4 text-indigo-400" />
                                                </div>
                                                <div className="text-left">
                                                    <div className="text-xs font-bold">{debt.name}</div>
                                                    <div className="text-[9px] opacity-70">${debt.current}</div>
                                                </div>
                                                {selectedDebt === debt.id.toString() && <div className="w-2 h-2 rounded-full bg-indigo-500 ml-auto"></div>}
                                            </button>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="p-4 rounded-2xl bg-black/20 border border-white/5 text-center">
                                        <p className="text-xs text-gray-500">No tienes deudas registradas.</p>
                                    </div>
                                )}
                             </>
                         ) : (
                             // --- CATEGORY SELECTOR ---
                             <>
                                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 block">{texts.transaction.category}</label>
                                <div className="grid grid-cols-2 gap-3 mb-6">
                                    {sections.flatMap(section => 
                                        section.items.map(item => (
                                            <button
                                                key={item.id}
                                                onClick={() => setSelectedCategory(item.id)}
                                                className={`p-3 rounded-2xl border flex items-center gap-3 transition-all text-left ${
                                                    selectedCategory === item.id
                                                    ? 'bg-white text-black border-white'
                                                    : 'bg-black/20 border-white/5 text-gray-300 hover:bg-white/5'
                                                }`}
                                            >
                                                {getCategoryIcon(section.id)}
                                                <span className="text-xs font-bold truncate">{item.name}</span>
                                            </button>
                                        ))
                                    )}
                                </div>
                             </>
                         )}
                    </div>
                )}

                {/* 4. WEEK START TOGGLE (Only for Income) */}
                {type === 'income' && (
                    <div className={`border rounded-2xl p-4 flex items-center justify-between animate-fade-in-up transition-colors ${isWeekStart ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-black/20 border-white/5'}`}>
                        <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isWeekStart ? 'bg-emerald-500/20' : 'bg-gray-800'}`}>
                                <AlertTriangle className={`w-5 h-5 ${isWeekStart ? 'text-emerald-400' : 'text-gray-500'}`} />
                            </div>
                            <div>
                                <p className={`text-sm font-bold ${isWeekStart ? 'text-emerald-100' : 'text-gray-300'}`}>{texts.transaction.weekStart}</p>
                                <p className={`text-[10px] ${isWeekStart ? 'text-emerald-200/70' : 'text-gray-500'}`}>
                                    {isWeekStart 
                                        ? texts.transaction.weekStartDesc 
                                        : texts.transaction.weekStartDescNo}
                                </p>
                            </div>
                        </div>
                        <button 
                            onClick={() => setIsWeekStart(!isWeekStart)}
                            className={`w-12 h-6 rounded-full p-1 transition-colors ${isWeekStart ? 'bg-emerald-500' : 'bg-gray-700'}`}
                        >
                            <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${isWeekStart ? 'translate-x-6' : 'translate-x-0'}`}></div>
                        </button>
                    </div>
                )}
                
                {/* 5. DESCRIPTION INPUT (Shows for Expense+Category OR Income) */}
                {((type === 'expense' && !isDebtPayment && selectedCategory) || type === 'income') && (
                    <div className="animate-fade-in-up">
                            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 block">{texts.transaction.description}</label>
                            <div className="relative">
                            <AlignLeft className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                            <input 
                                type="text"
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                placeholder={type === 'income' ? "Ej. Venta de garage" : "Ej. Tacos al pastor"}
                                className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 pl-10 text-white focus:outline-none focus:border-purple-500 text-sm"
                            />
                            </div>
                    </div>
                )}

            </div>

            {/* --- ACTION BUTTON FIXED BOTTOM --- */}
            <div className="absolute bottom-0 left-0 w-full bg-black/60 backdrop-blur-md p-6 border-t border-white/10 z-20">
                 <Button onClick={handleSave} disabled={(!amount || (type === 'expense' && !isDebtPayment && !selectedCategory) || (type === 'expense' && isDebtPayment && !selectedDebt) || !selectedMethod)}>
                     {type === 'expense' 
                        ? (isDebtPayment ? texts.transaction.registerDebt : texts.transaction.registerExpense) 
                        : (isWeekStart ? texts.transaction.startWeek : texts.transaction.registerIncome)}
                 </Button>
            </div>

        </div>

        {/* INTRO MODAL */}
        {internalShowIntro && (
            <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
                <div className="bg-surface border border-white/10 rounded-[2rem] p-8 w-full max-w-sm shadow-2xl relative overflow-hidden flex flex-col items-center">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-900 border border-white/10 flex items-center justify-center shadow-lg mb-6">
                        <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                    </div>
                    <h3 className="text-xl font-bold text-center mb-2">{texts.transaction.introTitle}</h3>
                    <p className="text-center text-gray-400 text-sm mb-6">
                        {texts.transaction.introText}
                    </p>
                    <Button onClick={() => { setInternalShowIntro(false); onIntroClosed && onIntroClosed(); }}>
                        {texts.common.understood.toUpperCase()}
                    </Button>
                </div>
            </div>
        )}

        {/* WARNING MODAL 1: BUDGET EXCEEDED */}
        {warningStep === 1 && (
             <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
                 <div className="bg-surface border border-yellow-500/30 rounded-[2rem] p-8 w-full max-w-sm shadow-[0_0_50px_rgba(234,179,8,0.2)] relative overflow-hidden flex flex-col items-center">
                     <div className="w-16 h-16 rounded-2xl bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center shadow-lg mb-6">
                         <AlertTriangle className="w-8 h-8 text-yellow-500" />
                     </div>
                     <h3 className="text-xl font-bold text-center mb-2 text-white">{texts.transaction.warning1Title}</h3>
                     <p className="text-center text-gray-300 text-sm mb-4 leading-relaxed">
                         {texts.transaction.warning1Text}
                     </p>
                     <p className="text-center text-yellow-500 font-bold text-sm mb-8">
                         {texts.transaction.warning1Question}
                     </p>
                     
                     <div className="w-full flex flex-col gap-3">
                         <Button onClick={() => setWarningStep(2)} className="bg-yellow-600 hover:bg-yellow-500 text-black font-bold border-none">
                             {texts.common.continue}
                         </Button>
                         <button 
                             onClick={() => { setWarningStep(0); setPendingSaveData(null); }}
                             className="w-full py-4 rounded-2xl text-gray-400 font-bold text-sm hover:text-white transition-colors"
                         >
                             {texts.common.cancel}
                         </button>
                     </div>
                 </div>
             </div>
        )}

        {/* WARNING MODAL 2: DOUBLE CONFIRMATION */}
        {warningStep === 2 && (
             <div className="absolute inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-6 animate-fade-in">
                 <div className="bg-surface border border-red-500/30 rounded-[2rem] p-8 w-full max-w-sm shadow-[0_0_50px_rgba(239,68,68,0.3)] relative overflow-hidden flex flex-col items-center">
                     <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center shadow-lg mb-6 animate-pulse">
                         <AlertOctagon className="w-8 h-8 text-red-500" />
                     </div>
                     <h3 className="text-xl font-bold text-center mb-2 text-red-400">{texts.transaction.warning2Title}</h3>
                     <p className="text-center text-gray-300 text-sm mb-8 leading-relaxed">
                         {texts.transaction.warning2Text}
                     </p>
                     
                     <div className="w-full flex flex-col gap-3">
                         <Button onClick={() => executeSave(pendingSaveData)} className="bg-red-600 hover:bg-red-500 text-white font-bold border-none">
                             {texts.common.yesSure}
                         </Button>
                         <button 
                             onClick={() => { setWarningStep(0); setPendingSaveData(null); }}
                             className="w-full py-4 rounded-2xl text-gray-400 font-bold text-sm hover:text-white transition-colors"
                         >
                             {texts.common.cancel}
                         </button>
                     </div>
                 </div>
             </div>
        )}

    </div>
  );
};