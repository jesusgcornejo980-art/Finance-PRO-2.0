import React from 'react';
import { CreditCard, Lock } from 'lucide-react';
import { Button } from '../Button';

interface Props {
  onNext: () => void;
}

export const WelcomeScreen: React.FC<Props> = ({ onNext }) => {
  return (
    <div className="flex flex-col h-full relative overflow-hidden">
      <style>{`
        @keyframes float {
          0% { transform: translateY(0px); box-shadow: 0 20px 25px -5px rgba(168, 85, 247, 0.3), 0 10px 10px -5px rgba(168, 85, 247, 0.2); }
          50% { transform: translateY(-15px); box-shadow: 0 35px 60px -15px rgba(217, 70, 239, 0.5), 0 20px 25px -5px rgba(217, 70, 239, 0.3); }
          100% { transform: translateY(0px); box-shadow: 0 20px 25px -5px rgba(168, 85, 247, 0.3), 0 10px 10px -5px rgba(168, 85, 247, 0.2); }
        }
        .animate-float {
          animation: float 5s ease-in-out infinite;
        }
      `}</style>

      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-1/2 bg-purple-900/20 blur-3xl rounded-full -translate-y-1/2 pointer-events-none" />

      <div className="flex-1 flex flex-col items-center justify-center p-6 z-10">
        <div className="animate-float w-24 h-24 bg-gradient-to-tr from-violet-600 to-fuchsia-600 rounded-3xl flex items-center justify-center mb-8 border border-white/10">
          <CreditCard className="w-12 h-12 text-white drop-shadow-md" />
        </div>

        <h1 className="text-4xl font-bold mb-4 text-center">
          Finance <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-fuchsia-400">PRO</span>
        </h1>

        <p className="text-lg text-center text-gray-200 mb-8 max-w-xs">
          Controla tu dinero semana a semana, sin estrés.
        </p>

        <p className="text-sm text-center text-gray-400 max-w-xs leading-relaxed">
          Estrategia de Gasto inteligente 50-30-20, control de deudas y dashboard automático en tiempo real.
        </p>
      </div>

      <div className="p-6 pb-8 z-10">
        <Button onClick={onNext}>
          COMENZAR
        </Button>
        
        <div className="flex items-center justify-center gap-2 mt-6 text-xs text-gray-500">
          <Lock className="w-3 h-3" />
          <span>Tus datos siempre bajo tu control</span>
        </div>
      </div>
    </div>
  );
};