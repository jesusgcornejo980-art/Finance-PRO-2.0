import React, { useState } from 'react';
import { Bell, Wallet, BarChart3, Plus, CreditCard, User, Home, AlertTriangle, ChevronDown, ChevronUp, X, Check, Info, ChevronLeft } from 'lucide-react';
import { DebtItem, Currency, Notification } from '../../types';
import { Button } from '../Button';

interface Props {
  onAddTransaction: () => void;
  weeklyBalance: number;
  spentAmounts: { needs: number; savings: number; wants: number };
  debts: DebtItem[];
  onGoToAnalysis?: () => void;
  onGoToCards?: () => void;
  onGoToProfile?: () => void;
  texts: any;
  currency: Currency;
  notifications: Notification[];
  onOpenNotifications: () => void;
  onDismissNotification: (id: string) => void;
}

export const Screen11: React.FC<Props> = ({ 
    onAddTransaction, 
    weeklyBalance, 
    spentAmounts, 
    debts, 
    onGoToAnalysis, 
    onGoToCards, 
    onGoToProfile, 
    texts, 
    currency,
    notifications,
    onOpenNotifications,
    onDismissNotification
}) => {
  const [showDebts, setShowDebts] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);
  
  const unreadCount = notifications.filter(n => !n.read).length;

  const handleBellClick = () => {
      setShowNotificationsModal(true);
      if (unreadCount > 0) {
        onOpenNotifications();
      }
  };

  const handleCloseNotifications = () => {
      setShowNotificationsModal(false);
      setSelectedNotification(null);
  };

  const handleNotificationClick = (notif: Notification) => {
      setSelectedNotification(notif);
  };

  const handleBackFromDetail = () => {
      if (selectedNotification) {
          onDismissNotification(selectedNotification.id);
          setSelectedNotification(null);
      }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 0
    }).format(value);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  };

  // Reconstruct Total Basis
  const totalBasis = weeklyBalance + spentAmounts.needs + spentAmounts.savings + spentAmounts.wants;

  // Calculate budgets
  const needsBudget = totalBasis * 0.50;
  const savingsBudget = totalBasis * 0.30;
  const wantsBudget = totalBasis * 0.20;

  // Calculate percentages
  const needsPercent = needsBudget > 0 ? (spentAmounts.needs / needsBudget) * 100 : 0;
  const savingsPercent = savingsBudget > 0 ? (spentAmounts.savings / savingsBudget) * 100 : 0;
  const wantsPercent = wantsBudget > 0 ? (spentAmounts.wants / wantsBudget) * 100 : 0;

  // Calculate Remaining (Available)
  const needsRemaining = needsBudget - spentAmounts.needs;
  const savingsRemaining = savingsBudget - spentAmounts.savings;
  const wantsRemaining = wantsBudget - spentAmounts.wants;

  // Debt Calculations
  const totalInitialDebt = debts.reduce((acc, d) => acc + (parseFloat(d.initial) || 0), 0);
  const totalCurrentDebt = debts.reduce((acc, d) => acc + (parseFloat(d.current) || 0), 0);
  const totalPaidDebt = totalInitialDebt - totalCurrentDebt;
  const globalDebtProgress = totalInitialDebt > 0 ? (totalPaidDebt / totalInitialDebt) * 100 : 0;

  // Helper to determine card styles based on percentage
  const getCardStyles = (percent: number, defaultStyles: any) => {
    // DANGER: Over 100% -> Red Blinking
    if (percent > 100) {
        return {
            container: 'bg-red-950/40 border-red-500 animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.4)]',
            stripe: 'bg-red-600',
            dot: 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]',
            textTitle: 'text-red-300',
            textAccent: 'text-red-400',
            bar: 'bg-gradient-to-r from-red-600 to-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]',
            icon: <AlertTriangle className="w-4 h-4 text-red-500" />
        };
    }
    // WARNING: Over 90% -> Yellow
    if (percent >= 90) {
        return {
            container: 'bg-yellow-950/40 border-yellow-500 shadow-[0_0_15px_rgba(234,179,8,0.2)]',
            stripe: 'bg-yellow-600',
            dot: 'bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.8)]',
            textTitle: 'text-yellow-200',
            textAccent: 'text-yellow-400',
            bar: 'bg-gradient-to-r from-yellow-600 to-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.5)]',
            icon: <AlertTriangle className="w-4 h-4 text-yellow-500" />
        };
    }
    // NORMAL: Default styling
    return {
        container: 'bg-[#12121a] border-white/5 shadow-lg',
        stripe: defaultStyles.stripe,
        dot: defaultStyles.dot,
        textTitle: 'text-gray-300',
        textAccent: defaultStyles.textAccent,
        bar: defaultStyles.bar,
        icon: defaultStyles.icon
    };
  };

  // Define default themes
  const needsStyles = getCardStyles(needsPercent, {
      stripe: 'bg-purple-600',
      dot: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]',
      textAccent: 'text-purple-400',
      bar: 'bg-gradient-to-r from-purple-700 to-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]',
      icon: <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]"></div>
  });

  const savingsStyles = getCardStyles(savingsPercent, {
      stripe: 'bg-fuchsia-600',
      dot: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]',
      textAccent: 'text-fuchsia-400',
      bar: 'bg-gradient-to-r from-fuchsia-700 to-fuchsia-500 shadow-[0_0_10px_rgba(217,70,239,0.5)]',
      icon: <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]"></div>
  });

  const wantsStyles = getCardStyles(wantsPercent, {
      stripe: 'bg-violet-600',
      dot: 'bg-yellow-400 shadow-[0_0_8px_rgba(250,204,21,0.8)]',
      textAccent: 'text-violet-400',
      bar: 'bg-gradient-to-r from-violet-700 to-violet-500 shadow-[0_0_10px_rgba(139,92,246,0.5)]',
      icon: <div className="w-2 h-2 rounded-full bg-yellow-400 shadow-[0_0_8px_rgba(250,204,21,0.8)]"></div>
  });

  return (
    <div className="flex flex-col h-full bg-black relative">
      
      {/* --- HEADER --- */}
      <div className="px-6 py-6 pt-10 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-violet-600 to-fuchsia-600 flex items-center justify-center">
                <Wallet className="w-4 h-4 text-white" />
            </div>
            <span className="text-xs font-bold text-fuchsia-500 tracking-widest uppercase">{texts.dashboard.currentWeek}</span>
        </div>
        <button 
            onClick={handleBellClick}
            className="w-10 h-10 rounded-2xl bg-surface border border-white/5 flex items-center justify-center text-gray-400 hover:text-white transition-colors relative"
        >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
                <div className="absolute top-3 right-3 w-2 h-2 rounded-full bg-fuchsia-500 border border-black animate-pulse"></div>
            )}
        </button>
      </div>

      {/* --- SCROLLABLE CONTENT --- */}
      <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
        
        {/* HERO BALANCE */}
        <div className="flex flex-col items-center justify-center mt-2 mb-8 relative">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-20 bg-purple-600/20 blur-[60px] rounded-full pointer-events-none"></div>
            <span className="text-sm text-gray-400 font-medium mb-1 relative z-10">{texts.dashboard.availableBalance}</span>
            <h1 className="text-5xl font-bold text-white relative z-10 drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]">
                {formatCurrency(weeklyBalance)}
            </h1>
        </div>

        {/* 50-30-20 DISTRIBUTION SECTION */}
        <div className="px-6 mb-8 animate-fade-in-up">
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-white">{texts.dashboard.autoDistribution}</h2>
                <span className="text-[10px] font-bold text-fuchsia-500 bg-fuchsia-500/10 px-2 py-1 rounded-md">REGLA 50-30-20</span>
            </div>

            <div className="space-y-4">
                {/* NEEDS CARD (50%) */}
                <div className={`border rounded-3xl p-5 relative overflow-hidden group transition-all duration-300 ${needsStyles.container}`}>
                    <div className={`absolute top-0 left-0 w-1 h-full ${needsStyles.stripe}`}></div>
                    
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-2">
                            {needsStyles.icon}
                            <span className={`text-xs font-bold uppercase tracking-wider ${needsStyles.textTitle}`}>{texts.dashboard.needs} (50%)</span>
                        </div>
                        <div className="text-right">
                             <span className="text-[10px] text-gray-500 uppercase block mb-0.5">{texts.dashboard.spent}</span>
                             <span className="text-white font-bold text-lg">{formatCurrency(spentAmounts.needs)}</span>
                        </div>
                    </div>

                    <div className="mb-4 flex justify-between items-end">
                         <div>
                             <span className={`text-[10px] font-bold uppercase block mb-1 ${needsStyles.textAccent}`}>{texts.dashboard.assigned}</span>
                             <span className="text-xl font-bold text-white block">{formatCurrency(needsBudget)}</span>
                         </div>
                         <div className="text-right">
                             <span className="text-[10px] text-gray-500 font-bold uppercase block mb-1">{texts.dashboard.remaining}</span>
                             <span className={`text-xl font-bold block ${needsRemaining < 0 ? 'text-red-400' : 'text-emerald-400'}`}>{formatCurrency(needsRemaining)}</span>
                         </div>
                    </div>

                    <div className="flex items-center gap-3">
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                                className={`h-full rounded-full transition-all duration-1000 ${needsStyles.bar}`}
                                style={{ width: `${Math.min(100, needsPercent)}%` }}
                            ></div>
                        </div>
                        <span className="text-[10px] text-gray-400 font-bold whitespace-nowrap">{Math.round(needsPercent)}% {texts.dashboard.ofCap}</span>
                    </div>
                </div>

                {/* SAVINGS CARD (30%) */}
                <div className={`border rounded-3xl p-5 relative overflow-hidden group transition-all duration-300 ${savingsStyles.container}`}>
                    <div className={`absolute top-0 left-0 w-1 h-full ${savingsStyles.stripe}`}></div>
                    
                    <div className="flex justify-between items-start mb-4">
                         <div className="flex items-center gap-2">
                            {savingsStyles.icon}
                            <span className={`text-xs font-bold uppercase tracking-wider ${savingsStyles.textTitle}`}>{texts.dashboard.savings} (30%)</span>
                        </div>
                        <div className="text-right">
                             <span className="text-[10px] text-gray-500 uppercase block mb-0.5">{texts.dashboard.spent}</span>
                             <span className="text-white font-bold text-lg">{formatCurrency(spentAmounts.savings)}</span>
                        </div>
                    </div>

                    <div className="mb-4 flex justify-between items-end">
                         <div>
                             <span className={`text-[10px] font-bold uppercase block mb-1 ${savingsStyles.textAccent}`}>{texts.dashboard.assigned}</span>
                             <span className="text-xl font-bold text-white block">{formatCurrency(savingsBudget)}</span>
                         </div>
                         <div className="text-right">
                             <span className="text-[10px] text-gray-500 font-bold uppercase block mb-1">{texts.dashboard.remaining}</span>
                             <span className={`text-xl font-bold block ${savingsRemaining < 0 ? 'text-red-400' : 'text-emerald-400'}`}>{formatCurrency(savingsRemaining)}</span>
                         </div>
                    </div>

                    <div className="flex items-center gap-3">
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                                className={`h-full rounded-full transition-all duration-1000 ${savingsStyles.bar}`}
                                style={{ width: `${Math.min(100, savingsPercent)}%` }}
                            ></div>
                        </div>
                        <span className="text-[10px] text-gray-400 font-bold whitespace-nowrap">{Math.round(savingsPercent)}% {texts.dashboard.ofCap}</span>
                    </div>
                </div>

                {/* WANTS CARD (20%) */}
                <div className={`border rounded-3xl p-5 relative overflow-hidden group transition-all duration-300 ${wantsStyles.container}`}>
                    <div className={`absolute top-0 left-0 w-1 h-full ${wantsStyles.stripe}`}></div>
                    
                    <div className="flex justify-between items-start mb-4">
                         <div className="flex items-center gap-2">
                            {wantsStyles.icon}
                            <span className={`text-xs font-bold uppercase tracking-wider ${wantsStyles.textTitle}`}>{texts.dashboard.wants} (20%)</span>
                        </div>
                        <div className="text-right">
                             <span className="text-[10px] text-gray-500 uppercase block mb-0.5">{texts.dashboard.spent}</span>
                             <span className="text-white font-bold text-lg">{formatCurrency(spentAmounts.wants)}</span>
                        </div>
                    </div>

                    <div className="mb-4 flex justify-between items-end">
                         <div>
                             <span className={`text-[10px] font-bold uppercase block mb-1 ${wantsStyles.textAccent}`}>{texts.dashboard.assigned}</span>
                             <span className="text-xl font-bold text-white block">{formatCurrency(wantsBudget)}</span>
                         </div>
                         <div className="text-right">
                             <span className="text-[10px] text-gray-500 font-bold uppercase block mb-1">{texts.dashboard.remaining}</span>
                             <span className={`text-xl font-bold block ${wantsRemaining < 0 ? 'text-red-400' : 'text-emerald-400'}`}>{formatCurrency(wantsRemaining)}</span>
                         </div>
                    </div>

                    <div className="flex items-center gap-3">
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                                className={`h-full rounded-full transition-all duration-1000 ${wantsStyles.bar}`}
                                style={{ width: `${Math.min(100, wantsPercent)}%` }}
                            ></div>
                        </div>
                        <span className="text-[10px] text-gray-400 font-bold whitespace-nowrap">{Math.round(wantsPercent)}% {texts.dashboard.ofCap}</span>
                    </div>
                </div>
            </div>
        </div>

        {/* DEBT PAYMENTS ACCORDION */}
        <div className="px-6 mb-8 animate-fade-in-up" style={{animationDelay: '100ms'}}>
            <div className="bg-[#12121a] border border-white/5 rounded-3xl p-5 overflow-hidden transition-all duration-300">
                <div 
                    className="flex items-center justify-between cursor-pointer" 
                    onClick={() => setShowDebts(!showDebts)}
                >
                    <div className="flex-1">
                        <h2 className="text-lg font-bold text-white mb-1">{texts.dashboard.myDebts}</h2>
                        <div className="flex items-center gap-3">
                             <div className="flex-1 h-1.5 bg-slate-800 rounded-full max-w-[120px] overflow-hidden">
                                <div 
                                    className="h-full bg-gradient-to-r from-purple-600 to-fuchsia-600"
                                    style={{ width: `${globalDebtProgress}%` }}
                                ></div>
                             </div>
                             <span className="text-[10px] font-bold text-fuchsia-400">{Math.round(globalDebtProgress)}% {texts.dashboard.paid}</span>
                        </div>
                    </div>
                    <div className={`p-2 rounded-full bg-white/5 text-gray-400 transition-transform duration-300 ${showDebts ? 'rotate-180' : ''}`}>
                         <ChevronDown className="w-5 h-5" />
                    </div>
                </div>

                {/* EXPANDABLE CONTENT */}
                {showDebts && (
                    <div className="mt-6 space-y-4 border-t border-white/5 pt-4 animate-fade-in">
                        {debts.length > 0 ? debts.map(debt => {
                            const initial = parseFloat(debt.initial) || 0;
                            const current = parseFloat(debt.current) || 0;
                            const paid = initial - current;
                            const progress = initial > 0 ? (paid / initial) * 100 : 0;
                            
                            return (
                                <div key={debt.id} className="bg-black/20 rounded-2xl p-4 border border-white/5">
                                    <div className="flex justify-between items-start mb-2">
                                        <span className="text-sm font-bold text-white">{debt.name}</span>
                                        <span className="text-xs font-bold text-fuchsia-400">{Math.round(progress)}%</span>
                                    </div>
                                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden mb-2">
                                        <div className="h-full bg-fuchsia-600" style={{ width: `${progress}%` }}></div>
                                    </div>
                                    <div className="flex justify-between text-[10px] text-gray-500">
                                        <span>Restante: {formatCurrency(current)}</span>
                                        <span>Total: {formatCurrency(initial)}</span>
                                    </div>
                                </div>
                            );
                        }) : (
                            <p className="text-center text-xs text-gray-500 py-2">No hay deudas registradas.</p>
                        )}
                        
                        <div className="text-center pt-2">
                            <span className="text-[10px] text-gray-600 uppercase tracking-widest">Pago Total Realizado: {formatCurrency(totalPaidDebt)}</span>
                        </div>
                    </div>
                )}
            </div>
        </div>

        {/* UPCOMING PAYMENTS */}
        <div className="px-6 mb-8 animate-fade-in-up" style={{animationDelay: '150ms'}}>
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-white">{texts.dashboard.upcomingPayments}</h2>
                <button className="text-[10px] font-bold text-fuchsia-500 uppercase hover:text-fuchsia-400">Ver Todos</button>
            </div>

            <div className="space-y-3">
                <div className="text-center py-6 border border-white/5 rounded-2xl bg-surface/50">
                    <p className="text-gray-500 text-xs">No hay pagos próximos registrados</p>
                </div>
            </div>
        </div>
      </div>

      {/* --- BOTTOM NAVIGATION BAR --- */}
      <div className="absolute bottom-0 left-0 w-full h-24 bg-black/90 backdrop-blur-xl border-t border-white/5 flex items-start justify-between px-6 pt-4 z-50">
          
          <button className="flex flex-col items-center gap-1 text-fuchsia-500">
             <div className="p-1 rounded-xl bg-fuchsia-500/10">
                <Home className="w-6 h-6" />
             </div>
             <span className="text-[10px] font-bold">{texts.dashboard.navBudget}</span>
          </button>

          <button onClick={onGoToAnalysis} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <BarChart3 className="w-6 h-6" />
             <span className="text-[10px] font-medium">{texts.dashboard.navAnalysis}</span>
          </button>

          {/* Floating Action Button */}
          <button 
            onClick={onAddTransaction}
            className="w-16 h-16 -mt-8 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 flex items-center justify-center shadow-[0_0_20px_rgba(192,38,211,0.4)] border-4 border-black active:scale-95 transition-transform"
          >
             <Plus className="w-8 h-8 text-white stroke-[3]" />
          </button>

          <button onClick={onGoToCards} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <CreditCard className="w-6 h-6" />
             <span className="text-[10px] font-medium">{texts.dashboard.navAccounts}</span>
          </button>

          <button onClick={onGoToProfile} className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-colors mt-1">
             <User className="w-6 h-6" />
             <span className="text-[10px] font-medium">{texts.dashboard.navProfile}</span>
          </button>
      </div>

      {/* --- NOTIFICATIONS MODAL --- */}
      {showNotificationsModal && (
          <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6 animate-fade-in">
              <div className="bg-surface border-t sm:border border-white/10 rounded-t-3xl sm:rounded-3xl p-6 w-full max-w-sm shadow-2xl animate-slide-up max-h-[85vh] overflow-y-auto no-scrollbar relative">
                  
                  {/* Modal Header */}
                  <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-white">
                            {selectedNotification ? 'Detalle de Notificación' : 'Notificaciones'}
                        </h3>
                        <button onClick={handleCloseNotifications} className="p-2 bg-slate-800 rounded-full text-gray-400 hover:text-white">
                            <X className="w-5 h-5" />
                        </button>
                  </div>

                  {/* Modal Content */}
                  <div className="space-y-4">
                      {selectedNotification ? (
                          // DETAIL VIEW
                          <div className="animate-fade-in">
                              <div className={`p-6 rounded-3xl border border-white/5 flex flex-col items-center text-center gap-4 ${
                                   selectedNotification.type === 'warning' ? 'bg-yellow-500/10' :
                                   selectedNotification.type === 'success' ? 'bg-emerald-500/10' :
                                   'bg-blue-500/10'
                              }`}>
                                   <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                                       selectedNotification.type === 'warning' ? 'bg-yellow-500/20 text-yellow-500' :
                                       selectedNotification.type === 'success' ? 'bg-emerald-500/20 text-emerald-500' :
                                       'bg-blue-500/20 text-blue-500'
                                   }`}>
                                       {selectedNotification.type === 'warning' ? <AlertTriangle className="w-8 h-8" /> :
                                        selectedNotification.type === 'success' ? <Check className="w-8 h-8" /> :
                                        <Info className="w-8 h-8" />
                                       }
                                   </div>
                                   <div>
                                       <h4 className="text-lg font-bold text-white mb-2">{selectedNotification.title}</h4>
                                       <p className="text-sm text-gray-300 leading-relaxed mb-4">{selectedNotification.message}</p>
                                       <p className="text-xs text-gray-500 font-bold">{formatDate(selectedNotification.date)}</p>
                                   </div>
                              </div>
                              
                              <div className="mt-6">
                                  <Button onClick={handleBackFromDetail} showIcon={false}>
                                      COMPRENDIDO / ARCHIVAR
                                  </Button>
                              </div>
                          </div>
                      ) : (
                          // LIST VIEW
                          notifications.length > 0 ? (
                              notifications.map((notif) => (
                                  <div 
                                    key={notif.id} 
                                    onClick={() => handleNotificationClick(notif)}
                                    className={`p-4 rounded-2xl border ${notif.read ? 'bg-black/20 border-white/5' : 'bg-surface border-purple-500/20'} flex items-start gap-4 cursor-pointer hover:bg-white/5 transition-colors`}
                                  >
                                       <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                                           notif.type === 'warning' ? 'bg-yellow-500/10 text-yellow-500' :
                                           notif.type === 'success' ? 'bg-emerald-500/10 text-emerald-500' :
                                           'bg-blue-500/10 text-blue-500'
                                       }`}>
                                           {notif.type === 'warning' ? <AlertTriangle className="w-5 h-5" /> :
                                            notif.type === 'success' ? <Check className="w-5 h-5" /> :
                                            <Info className="w-5 h-5" />
                                           }
                                       </div>
                                       <div className="flex-1">
                                           <div className="flex justify-between items-start">
                                                <h4 className={`text-sm font-bold ${notif.read ? 'text-gray-300' : 'text-white'}`}>{notif.title}</h4>
                                                {!notif.read && <div className="w-2 h-2 rounded-full bg-fuchsia-500 mt-1"></div>}
                                           </div>
                                           <p className="text-xs text-gray-400 mt-1 leading-relaxed line-clamp-2">{notif.message}</p>
                                           <p className="text-[10px] text-gray-600 mt-2 font-medium">{formatDate(notif.date)}</p>
                                       </div>
                                  </div>
                              ))
                          ) : (
                              <div className="py-10 text-center text-gray-500">
                                  <p>No tienes notificaciones nuevas.</p>
                              </div>
                          )
                      )}
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};